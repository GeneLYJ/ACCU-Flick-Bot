/*******************************************************************************
* File Name: Compass_PM.c
* Version 3.50
*
* Description:
*  This file provides low power mode APIs for the I2C component.
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "Compass_PVT.h"

Compass_BACKUP_STRUCT Compass_backup =
{
    Compass_DISABLE,

#if (Compass_FF_IMPLEMENTED)
    Compass_DEFAULT_XCFG,
    Compass_DEFAULT_CFG,
    Compass_DEFAULT_ADDR,
    LO8(Compass_DEFAULT_DIVIDE_FACTOR),
    HI8(Compass_DEFAULT_DIVIDE_FACTOR),
#else  /* (Compass_UDB_IMPLEMENTED) */
    Compass_DEFAULT_CFG,
#endif /* (Compass_FF_IMPLEMENTED) */

#if (Compass_TIMEOUT_ENABLED)
    Compass_DEFAULT_TMOUT_PERIOD,
    Compass_DEFAULT_TMOUT_INTR_MASK,
#endif /* (Compass_TIMEOUT_ENABLED) */
};

#if ((Compass_FF_IMPLEMENTED) && (Compass_WAKEUP_ENABLED))
    volatile uint8 Compass_wakeupSource;
#endif /* ((Compass_FF_IMPLEMENTED) && (Compass_WAKEUP_ENABLED)) */


/*******************************************************************************
* Function Name: Compass_SaveConfig
********************************************************************************
*
* Summary:
*  The Enable wakeup from Sleep Mode selection influences this function
*  implementation:
*   Unchecked: Stores the component non-retention configuration registers.
*   Checked:   Disables the master, if it was enabled before, and enables
*              backup regulator of the I2C hardware. If a transaction intended
*              for component executes during this function call, it waits until
*              the current transaction is completed and I2C hardware is ready
*              to enter sleep mode. All subsequent I2C traffic is NAKed until
*              the device is put into sleep mode.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  Compass_backup - The global variable used to save the component
*                            configuration and non-retention registers before
*                            entering the sleep mode.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void Compass_SaveConfig(void) 
{
#if (Compass_FF_IMPLEMENTED)
    #if (Compass_WAKEUP_ENABLED)
        uint8 intState;
    #endif /* (Compass_WAKEUP_ENABLED) */

    /* Store registers before enter low power mode */
    Compass_backup.cfg     = Compass_CFG_REG;
    Compass_backup.xcfg    = Compass_XCFG_REG;
    Compass_backup.addr    = Compass_ADDR_REG;
    Compass_backup.clkDiv1 = Compass_CLKDIV1_REG;
    Compass_backup.clkDiv2 = Compass_CLKDIV2_REG;

#if (Compass_WAKEUP_ENABLED)
    /* Disable master */
    Compass_CFG_REG &= (uint8) ~Compass_ENABLE_MASTER;

    /* Enable backup regulator to keep block powered in low power mode */
    intState = CyEnterCriticalSection();
    Compass_PWRSYS_CR1_REG |= Compass_PWRSYS_CR1_I2C_REG_BACKUP;
    CyExitCriticalSection(intState);

    /* 1) Set force NACK to ignore I2C transactions;
    *  2) Wait unti I2C is ready go to Sleep; !!
    *  3) These bits are cleared on wake up.
    */
    /* Wait when block is ready for sleep */
    Compass_XCFG_REG |= Compass_XCFG_FORCE_NACK;
    while (0u == (Compass_XCFG_REG & Compass_XCFG_RDY_TO_SLEEP))
    {
    }

    /* Setup wakeup interrupt */
    Compass_DisableInt();
    (void) CyIntSetVector(Compass_ISR_NUMBER, &Compass_WAKEUP_ISR);
    Compass_wakeupSource = 0u;
    Compass_EnableInt();
#endif /* (Compass_WAKEUP_ENABLED) */

#else
    /* Store only address match bit */
    Compass_backup.control = (Compass_CFG_REG & Compass_CTRL_ANY_ADDRESS_MASK);
#endif /* (Compass_FF_IMPLEMENTED) */

#if (Compass_TIMEOUT_ENABLED)
    Compass_TimeoutSaveConfig();
#endif /* (Compass_TIMEOUT_ENABLED) */
}


/*******************************************************************************
* Function Name: Compass_Sleep
********************************************************************************
*
* Summary:
*  This is the preferred method to prepare the component before device enters
*  sleep mode. The Enable wakeup from Sleep Mode selection influences this
*  function implementation:
*   Unchecked: Checks current I2C component state, saves it, and disables the
*              component by calling I2C_Stop() if it is currently enabled.
*              I2C_SaveConfig() is then called to save the component
*              non-retention configuration registers.
*   Checked:   If a transaction intended for component executes during this
*              function call, it waits until the current transaction is
*              completed. All subsequent I2C traffic intended for component
*              is NAKed until the device is put to sleep mode. The address
*              match event wakes up the device.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void Compass_Sleep(void) 
{
#if (Compass_WAKEUP_ENABLED)
    /* Do not enable block after exit low power mode if it is wakeup source */
    Compass_backup.enableState = Compass_DISABLE;

    #if (Compass_TIMEOUT_ENABLED)
        Compass_TimeoutStop();
    #endif /* (Compass_TIMEOUT_ENABLED) */

#else
    /* Store enable state */
    Compass_backup.enableState = (uint8) Compass_IS_ENABLED;

    if (0u != Compass_backup.enableState)
    {
        Compass_Stop();
    }
#endif /* (Compass_WAKEUP_ENABLED) */

    Compass_SaveConfig();
}


/*******************************************************************************
* Function Name: Compass_RestoreConfig
********************************************************************************
*
* Summary:
*  The Enable wakeup from Sleep Mode selection influences this function
*  implementation:
*   Unchecked: Restores the component non-retention configuration registers
*              to the state they were in before I2C_Sleep() or I2C_SaveConfig()
*              was called.
*   Checked:   Disables the backup regulator of the I2C hardware. Sets up the
*              regular component interrupt handler and generates the component
*              interrupt if it was wake up source to release the bus and
*              continue in-coming I2C transaction.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global Variables:
*  Compass_backup - The global variable used to save the component
*                            configuration and non-retention registers before
*                            exiting the sleep mode.
*
* Reentrant:
*  No.
*
* Side Effects:
*  Calling this function before Compass_SaveConfig() or
*  Compass_Sleep() will lead to unpredictable results.
*
*******************************************************************************/
void Compass_RestoreConfig(void) 
{
#if (Compass_FF_IMPLEMENTED)
    uint8 intState;

    if (Compass_CHECK_PWRSYS_I2C_BACKUP)
    /* Low power mode was Sleep - backup regulator is enabled */
    {
        /* Enable backup regulator in active mode */
        intState = CyEnterCriticalSection();
        Compass_PWRSYS_CR1_REG &= (uint8) ~Compass_PWRSYS_CR1_I2C_REG_BACKUP;
        CyExitCriticalSection(intState);

        /* Restore master */
        Compass_CFG_REG = Compass_backup.cfg;
    }
    else
    /* Low power mode was Hibernate - backup regulator is disabled. All registers are cleared */
    {
    #if (Compass_WAKEUP_ENABLED)
        /* Disable power to block before register restore */
        intState = CyEnterCriticalSection();
        Compass_ACT_PWRMGR_REG  &= (uint8) ~Compass_ACT_PWR_EN;
        Compass_STBY_PWRMGR_REG &= (uint8) ~Compass_STBY_PWR_EN;
        CyExitCriticalSection(intState);

        /* Enable component in I2C_Wakeup() after register restore */
        Compass_backup.enableState = Compass_ENABLE;
    #endif /* (Compass_WAKEUP_ENABLED) */

        /* Restore component registers after Hibernate */
        Compass_XCFG_REG    = Compass_backup.xcfg;
        Compass_CFG_REG     = Compass_backup.cfg;
        Compass_ADDR_REG    = Compass_backup.addr;
        Compass_CLKDIV1_REG = Compass_backup.clkDiv1;
        Compass_CLKDIV2_REG = Compass_backup.clkDiv2;
    }

#if (Compass_WAKEUP_ENABLED)
    Compass_DisableInt();
    (void) CyIntSetVector(Compass_ISR_NUMBER, &Compass_ISR);
    if (0u != Compass_wakeupSource)
    {
        /* Generate interrupt to process incoming transaction */
        Compass_SetPendingInt();
    }
    Compass_EnableInt();
#endif /* (Compass_WAKEUP_ENABLED) */

#else
    Compass_CFG_REG = Compass_backup.control;
#endif /* (Compass_FF_IMPLEMENTED) */

#if (Compass_TIMEOUT_ENABLED)
    Compass_TimeoutRestoreConfig();
#endif /* (Compass_TIMEOUT_ENABLED) */
}


/*******************************************************************************
* Function Name: Compass_Wakeup
********************************************************************************
*
* Summary:
*  This is the preferred method to prepare the component for active mode
*  operation (when device exits sleep mode). The Enable wakeup from Sleep Mode
*  selection influences this function implementation:
*   Unchecked: Restores the component non-retention configuration registers
*              by calling I2C_RestoreConfig(). If the component was enabled
*              before the I2C_Sleep() function was called, I2C_Wakeup()
*              re-enables it.
*   Checked:   Enables  master functionality if it was enabled before sleep,
*              and disables the backup regulator of the I2C hardware.
*              The incoming transaction continues as soon as the regular
*              I2C interrupt handler is set up (global interrupts has to be
*              enabled to service I2C component interrupt).
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Reentrant:
*  No.
*
* Side Effects:
*  Calling this function before Compass_SaveConfig() or
*  Compass_Sleep() will lead to unpredictable results.
*
*******************************************************************************/
void Compass_Wakeup(void) 
{
    Compass_RestoreConfig();

    /* Restore component enable state */
    if (0u != Compass_backup.enableState)
    {
        Compass_Enable();
        Compass_EnableInt();
    }
    else
    {
    #if (Compass_TIMEOUT_ENABLED)
        Compass_TimeoutEnable();
    #endif /* (Compass_TIMEOUT_ENABLED) */
    }
}


/* [] END OF FILE */
