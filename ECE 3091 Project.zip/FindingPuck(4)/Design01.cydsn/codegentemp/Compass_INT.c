/*******************************************************************************
* File Name: Compass_INT.c
* Version 3.50
*
* Description:
*  This file provides the source code of Interrupt Service Routine (ISR)
*  for the I2C component.
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "Compass_PVT.h"
#include "cyapicallbacks.h"


/*******************************************************************************
*  Place your includes, defines and code here.
********************************************************************************/
/* `#START Compass_ISR_intc` */

/* `#END` */


/*******************************************************************************
* Function Name: Compass_ISR
********************************************************************************
*
* Summary:
*  The handler for the I2C interrupt. The slave and master operations are
*  handled here.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Reentrant:
*  No.
*
*******************************************************************************/
CY_ISR(Compass_ISR)
{
#if (Compass_MODE_SLAVE_ENABLED)
   uint8  tmp8;
#endif  /* (Compass_MODE_SLAVE_ENABLED) */

    uint8  tmpCsr;
    
#ifdef Compass_ISR_ENTRY_CALLBACK
    Compass_ISR_EntryCallback();
#endif /* Compass_ISR_ENTRY_CALLBACK */
    

#if(Compass_TIMEOUT_FF_ENABLED)
    if(0u != Compass_TimeoutGetStatus())
    {
        Compass_TimeoutReset();
        Compass_state = Compass_SM_EXIT_IDLE;
        /* Compass_CSR_REG should be cleared after reset */
    }
#endif /* (Compass_TIMEOUT_FF_ENABLED) */


    tmpCsr = Compass_CSR_REG;      /* Make copy as interrupts clear */

#if(Compass_MODE_MULTI_MASTER_SLAVE_ENABLED)
    if(Compass_CHECK_START_GEN(Compass_MCSR_REG))
    {
        Compass_CLEAR_START_GEN;

        /* Set transfer complete and error flags */
        Compass_mstrStatus |= (Compass_MSTAT_ERR_XFER |
                                        Compass_GET_MSTAT_CMPLT);

        /* Slave was addressed */
        Compass_state = Compass_SM_SLAVE;
    }
#endif /* (Compass_MODE_MULTI_MASTER_SLAVE_ENABLED) */


#if(Compass_MODE_MULTI_MASTER_ENABLED)
    if(Compass_CHECK_LOST_ARB(tmpCsr))
    {
        /* Set errors */
        Compass_mstrStatus |= (Compass_MSTAT_ERR_XFER     |
                                        Compass_MSTAT_ERR_ARB_LOST |
                                        Compass_GET_MSTAT_CMPLT);

        Compass_DISABLE_INT_ON_STOP; /* Interrupt on Stop is enabled by write */

        #if(Compass_MODE_MULTI_MASTER_SLAVE_ENABLED)
            if(Compass_CHECK_ADDRESS_STS(tmpCsr))
            {
                /* Slave was addressed */
                Compass_state = Compass_SM_SLAVE;
            }
            else
            {
                Compass_BUS_RELEASE;

                Compass_state = Compass_SM_EXIT_IDLE;
            }
        #else
            Compass_BUS_RELEASE;

            Compass_state = Compass_SM_EXIT_IDLE;

        #endif /* (Compass_MODE_MULTI_MASTER_SLAVE_ENABLED) */
    }
#endif /* (Compass_MODE_MULTI_MASTER_ENABLED) */

    /* Check for master operation mode */
    if(Compass_CHECK_SM_MASTER)
    {
    #if(Compass_MODE_MASTER_ENABLED)
        if(Compass_CHECK_BYTE_COMPLETE(tmpCsr))
        {
            switch (Compass_state)
            {
            case Compass_SM_MSTR_WR_ADDR:  /* After address is sent, write data */
            case Compass_SM_MSTR_RD_ADDR:  /* After address is sent, read data */

                tmpCsr &= ((uint8) ~Compass_CSR_STOP_STATUS); /* Clear Stop bit history on address phase */

                if(Compass_CHECK_ADDR_ACK(tmpCsr))
                {
                    /* Setup for transmit or receive of data */
                    if(Compass_state == Compass_SM_MSTR_WR_ADDR)   /* TRANSMIT data */
                    {
                        /* Check if at least one byte to transfer */
                        if(Compass_mstrWrBufSize > 0u)
                        {
                            /* Load the 1st data byte */
                            Compass_DATA_REG = Compass_mstrWrBufPtr[0u];
                            Compass_TRANSMIT_DATA;
                            Compass_mstrWrBufIndex = 1u;   /* Set index to 2nd element */

                            /* Set transmit state until done */
                            Compass_state = Compass_SM_MSTR_WR_DATA;
                        }
                        /* End of buffer: complete writing */
                        else if(Compass_CHECK_NO_STOP(Compass_mstrControl))
                        {
                            /* Set write complete and master halted */
                            Compass_mstrStatus |= (Compass_MSTAT_XFER_HALT |
                                                            Compass_MSTAT_WR_CMPLT);

                            Compass_state = Compass_SM_MSTR_HALT; /* Expect ReStart */
                            Compass_DisableInt();
                        }
                        else
                        {
                            Compass_ENABLE_INT_ON_STOP; /* Enable interrupt on Stop, to catch it */
                            Compass_GENERATE_STOP;
                        }
                    }
                    else  /* Master receive data */
                    {
                        Compass_READY_TO_READ; /* Release bus to read data */

                        Compass_state  = Compass_SM_MSTR_RD_DATA;
                    }
                }
                /* Address is NACKed */
                else if(Compass_CHECK_ADDR_NAK(tmpCsr))
                {
                    /* Set Address NAK error */
                    Compass_mstrStatus |= (Compass_MSTAT_ERR_XFER |
                                                    Compass_MSTAT_ERR_ADDR_NAK);

                    if(Compass_CHECK_NO_STOP(Compass_mstrControl))
                    {
                        Compass_mstrStatus |= (Compass_MSTAT_XFER_HALT |
                                                        Compass_GET_MSTAT_CMPLT);

                        Compass_state = Compass_SM_MSTR_HALT; /* Expect RESTART */
                        Compass_DisableInt();
                    }
                    else  /* Do normal Stop */
                    {
                        Compass_ENABLE_INT_ON_STOP; /* Enable interrupt on Stop, to catch it */
                        Compass_GENERATE_STOP;
                    }
                }
                else
                {
                    /* Address phase is not set for some reason: error */
                    #if(Compass_TIMEOUT_ENABLED)
                        /* Exit interrupt to take chance for timeout timer to handle this case */
                        Compass_DisableInt();
                        Compass_ClearPendingInt();
                    #else
                        /* Block execution flow: unexpected condition */
                        CYASSERT(0u != 0u);
                    #endif /* (Compass_TIMEOUT_ENABLED) */
                }
                break;

            case Compass_SM_MSTR_WR_DATA:

                if(Compass_CHECK_DATA_ACK(tmpCsr))
                {
                    /* Check if end of buffer */
                    if(Compass_mstrWrBufIndex  < Compass_mstrWrBufSize)
                    {
                        Compass_DATA_REG =
                                                 Compass_mstrWrBufPtr[Compass_mstrWrBufIndex];
                        Compass_TRANSMIT_DATA;
                        Compass_mstrWrBufIndex++;
                    }
                    /* End of buffer: complete writing */
                    else if(Compass_CHECK_NO_STOP(Compass_mstrControl))
                    {
                        /* Set write complete and master halted */
                        Compass_mstrStatus |= (Compass_MSTAT_XFER_HALT |
                                                        Compass_MSTAT_WR_CMPLT);

                        Compass_state = Compass_SM_MSTR_HALT;    /* Expect restart */
                        Compass_DisableInt();
                    }
                    else  /* Do normal Stop */
                    {
                        Compass_ENABLE_INT_ON_STOP;    /* Enable interrupt on Stop, to catch it */
                        Compass_GENERATE_STOP;
                    }
                }
                /* Last byte NAKed: end writing */
                else if(Compass_CHECK_NO_STOP(Compass_mstrControl))
                {
                    /* Set write complete, short transfer and master halted */
                    Compass_mstrStatus |= (Compass_MSTAT_ERR_XFER       |
                                                    Compass_MSTAT_ERR_SHORT_XFER |
                                                    Compass_MSTAT_XFER_HALT      |
                                                    Compass_MSTAT_WR_CMPLT);

                    Compass_state = Compass_SM_MSTR_HALT;    /* Expect ReStart */
                    Compass_DisableInt();
                }
                else  /* Do normal Stop */
                {
                    Compass_ENABLE_INT_ON_STOP;    /* Enable interrupt on Stop, to catch it */
                    Compass_GENERATE_STOP;

                    /* Set short transfer and error flag */
                    Compass_mstrStatus |= (Compass_MSTAT_ERR_SHORT_XFER |
                                                    Compass_MSTAT_ERR_XFER);
                }

                break;

            case Compass_SM_MSTR_RD_DATA:

                Compass_mstrRdBufPtr[Compass_mstrRdBufIndex] = Compass_DATA_REG;
                Compass_mstrRdBufIndex++;

                /* Check if end of buffer */
                if(Compass_mstrRdBufIndex < Compass_mstrRdBufSize)
                {
                    Compass_ACK_AND_RECEIVE;       /* ACK and receive byte */
                }
                /* End of buffer: complete reading */
                else if(Compass_CHECK_NO_STOP(Compass_mstrControl))
                {
                    /* Set read complete and master halted */
                    Compass_mstrStatus |= (Compass_MSTAT_XFER_HALT |
                                                    Compass_MSTAT_RD_CMPLT);

                    Compass_state = Compass_SM_MSTR_HALT;    /* Expect ReStart */
                    Compass_DisableInt();
                }
                else
                {
                    Compass_ENABLE_INT_ON_STOP;
                    Compass_NAK_AND_RECEIVE;       /* NACK and TRY to generate Stop */
                }
                break;

            default: /* This is an invalid state and should not occur */

            #if(Compass_TIMEOUT_ENABLED)
                /* Exit interrupt to take chance for timeout timer to handles this case */
                Compass_DisableInt();
                Compass_ClearPendingInt();
            #else
                /* Block execution flow: unexpected condition */
                CYASSERT(0u != 0u);
            #endif /* (Compass_TIMEOUT_ENABLED) */

                break;
            }
        }

        /* Catches Stop: end of transaction */
        if(Compass_CHECK_STOP_STS(tmpCsr))
        {
            Compass_mstrStatus |= Compass_GET_MSTAT_CMPLT;

            Compass_DISABLE_INT_ON_STOP;
            Compass_state = Compass_SM_IDLE;
        }
    #endif /* (Compass_MODE_MASTER_ENABLED) */
    }
    else if(Compass_CHECK_SM_SLAVE)
    {
    #if(Compass_MODE_SLAVE_ENABLED)

        if((Compass_CHECK_STOP_STS(tmpCsr)) || /* Stop || Restart */
           (Compass_CHECK_BYTE_COMPLETE(tmpCsr) && Compass_CHECK_ADDRESS_STS(tmpCsr)))
        {
            /* Catch end of master write transaction: use interrupt on Stop */
            /* The Stop bit history on address phase does not have correct state */
            if(Compass_SM_SL_WR_DATA == Compass_state)
            {
                Compass_DISABLE_INT_ON_STOP;

                Compass_slStatus &= ((uint8) ~Compass_SSTAT_WR_BUSY);
                Compass_slStatus |= ((uint8)  Compass_SSTAT_WR_CMPLT);

                Compass_state = Compass_SM_IDLE;
            }
        }

        if(Compass_CHECK_BYTE_COMPLETE(tmpCsr))
        {
            /* The address only issued after Start or ReStart: so check the address
               to catch these events:
                FF : sets an address phase with a byte_complete interrupt trigger.
                UDB: sets an address phase immediately after Start or ReStart. */
            if(Compass_CHECK_ADDRESS_STS(tmpCsr))
            {
            /* Check for software address detection */
            #if(Compass_SW_ADRR_DECODE)
                tmp8 = Compass_GET_SLAVE_ADDR(Compass_DATA_REG);

                if(tmp8 == Compass_slAddress)   /* Check for address match */
                {
                    if(0u != (Compass_DATA_REG & Compass_READ_FLAG))
                    {
                        /* Place code to prepare read buffer here                  */
                        /* `#START Compass_SW_PREPARE_READ_BUF_interrupt` */

                        /* `#END` */

                    #ifdef Compass_SW_PREPARE_READ_BUF_CALLBACK
                        Compass_SwPrepareReadBuf_Callback();
                    #endif /* Compass_SW_PREPARE_READ_BUF_CALLBACK */
                        
                        /* Prepare next operation to read, get data and place in data register */
                        if(Compass_slRdBufIndex < Compass_slRdBufSize)
                        {
                            /* Load first data byte from array */
                            Compass_DATA_REG = Compass_slRdBufPtr[Compass_slRdBufIndex];
                            Compass_ACK_AND_TRANSMIT;
                            Compass_slRdBufIndex++;

                            Compass_slStatus |= Compass_SSTAT_RD_BUSY;
                        }
                        else    /* Overflow: provide 0xFF on bus */
                        {
                            Compass_DATA_REG = Compass_OVERFLOW_RETURN;
                            Compass_ACK_AND_TRANSMIT;

                            Compass_slStatus  |= (Compass_SSTAT_RD_BUSY |
                                                           Compass_SSTAT_RD_ERR_OVFL);
                        }

                        Compass_state = Compass_SM_SL_RD_DATA;
                    }
                    else  /* Write transaction: receive 1st byte */
                    {
                        Compass_ACK_AND_RECEIVE;
                        Compass_state = Compass_SM_SL_WR_DATA;

                        Compass_slStatus |= Compass_SSTAT_WR_BUSY;
                        Compass_ENABLE_INT_ON_STOP;
                    }
                }
                else
                {
                    /*     Place code to compare for additional address here    */
                    /* `#START Compass_SW_ADDR_COMPARE_interruptStart` */

                    /* `#END` */

                #ifdef Compass_SW_ADDR_COMPARE_ENTRY_CALLBACK
                    Compass_SwAddrCompare_EntryCallback();
                #endif /* Compass_SW_ADDR_COMPARE_ENTRY_CALLBACK */
                    
                    Compass_NAK_AND_RECEIVE;   /* NACK address */

                    /* Place code to end of condition for NACK generation here */
                    /* `#START Compass_SW_ADDR_COMPARE_interruptEnd`  */

                    /* `#END` */

                #ifdef Compass_SW_ADDR_COMPARE_EXIT_CALLBACK
                    Compass_SwAddrCompare_ExitCallback();
                #endif /* Compass_SW_ADDR_COMPARE_EXIT_CALLBACK */
                }

            #else /* (Compass_HW_ADRR_DECODE) */

                if(0u != (Compass_DATA_REG & Compass_READ_FLAG))
                {
                    /* Place code to prepare read buffer here                  */
                    /* `#START Compass_HW_PREPARE_READ_BUF_interrupt` */

                    /* `#END` */
                    
                #ifdef Compass_HW_PREPARE_READ_BUF_CALLBACK
                    Compass_HwPrepareReadBuf_Callback();
                #endif /* Compass_HW_PREPARE_READ_BUF_CALLBACK */

                    /* Prepare next operation to read, get data and place in data register */
                    if(Compass_slRdBufIndex < Compass_slRdBufSize)
                    {
                        /* Load first data byte from array */
                        Compass_DATA_REG = Compass_slRdBufPtr[Compass_slRdBufIndex];
                        Compass_ACK_AND_TRANSMIT;
                        Compass_slRdBufIndex++;

                        Compass_slStatus |= Compass_SSTAT_RD_BUSY;
                    }
                    else    /* Overflow: provide 0xFF on bus */
                    {
                        Compass_DATA_REG = Compass_OVERFLOW_RETURN;
                        Compass_ACK_AND_TRANSMIT;

                        Compass_slStatus  |= (Compass_SSTAT_RD_BUSY |
                                                       Compass_SSTAT_RD_ERR_OVFL);
                    }

                    Compass_state = Compass_SM_SL_RD_DATA;
                }
                else  /* Write transaction: receive 1st byte */
                {
                    Compass_ACK_AND_RECEIVE;
                    Compass_state = Compass_SM_SL_WR_DATA;

                    Compass_slStatus |= Compass_SSTAT_WR_BUSY;
                    Compass_ENABLE_INT_ON_STOP;
                }

            #endif /* (Compass_SW_ADRR_DECODE) */
            }
            /* Data states */
            /* Data master writes into slave */
            else if(Compass_state == Compass_SM_SL_WR_DATA)
            {
                if(Compass_slWrBufIndex < Compass_slWrBufSize)
                {
                    tmp8 = Compass_DATA_REG;
                    Compass_ACK_AND_RECEIVE;
                    Compass_slWrBufPtr[Compass_slWrBufIndex] = tmp8;
                    Compass_slWrBufIndex++;
                }
                else  /* of array: complete write, send NACK */
                {
                    Compass_NAK_AND_RECEIVE;

                    Compass_slStatus |= Compass_SSTAT_WR_ERR_OVFL;
                }
            }
            /* Data master reads from slave */
            else if(Compass_state == Compass_SM_SL_RD_DATA)
            {
                if(Compass_CHECK_DATA_ACK(tmpCsr))
                {
                    if(Compass_slRdBufIndex < Compass_slRdBufSize)
                    {
                         /* Get data from array */
                        Compass_DATA_REG = Compass_slRdBufPtr[Compass_slRdBufIndex];
                        Compass_TRANSMIT_DATA;
                        Compass_slRdBufIndex++;
                    }
                    else   /* Overflow: provide 0xFF on bus */
                    {
                        Compass_DATA_REG = Compass_OVERFLOW_RETURN;
                        Compass_TRANSMIT_DATA;

                        Compass_slStatus |= Compass_SSTAT_RD_ERR_OVFL;
                    }
                }
                else  /* Last byte was NACKed: read complete */
                {
                    /* Only NACK appears on bus */
                    Compass_DATA_REG = Compass_OVERFLOW_RETURN;
                    Compass_NAK_AND_TRANSMIT;

                    Compass_slStatus &= ((uint8) ~Compass_SSTAT_RD_BUSY);
                    Compass_slStatus |= ((uint8)  Compass_SSTAT_RD_CMPLT);

                    Compass_state = Compass_SM_IDLE;
                }
            }
            else
            {
            #if(Compass_TIMEOUT_ENABLED)
                /* Exit interrupt to take chance for timeout timer to handle this case */
                Compass_DisableInt();
                Compass_ClearPendingInt();
            #else
                /* Block execution flow: unexpected condition */
                CYASSERT(0u != 0u);
            #endif /* (Compass_TIMEOUT_ENABLED) */
            }
        }
    #endif /* (Compass_MODE_SLAVE_ENABLED) */
    }
    else
    {
        /* The FSM skips master and slave processing: return to IDLE */
        Compass_state = Compass_SM_IDLE;
    }

#ifdef Compass_ISR_EXIT_CALLBACK
    Compass_ISR_ExitCallback();
#endif /* Compass_ISR_EXIT_CALLBACK */    
}


#if ((Compass_FF_IMPLEMENTED) && (Compass_WAKEUP_ENABLED))
    /*******************************************************************************
    * Function Name: Compass_WAKEUP_ISR
    ********************************************************************************
    *
    * Summary:
    *  The interrupt handler to trigger after a wakeup.
    *
    * Parameters:
    *  None.
    *
    * Return:
    *  None.
    *
    *******************************************************************************/
    CY_ISR(Compass_WAKEUP_ISR)
    {
    #ifdef Compass_WAKEUP_ISR_ENTRY_CALLBACK
        Compass_WAKEUP_ISR_EntryCallback();
    #endif /* Compass_WAKEUP_ISR_ENTRY_CALLBACK */
         
        /* Set flag to notify that matched address is received */
        Compass_wakeupSource = 1u;

        /* SCL is stretched until the I2C_Wake() is called */

    #ifdef Compass_WAKEUP_ISR_EXIT_CALLBACK
        Compass_WAKEUP_ISR_ExitCallback();
    #endif /* Compass_WAKEUP_ISR_EXIT_CALLBACK */
    }
#endif /* ((Compass_FF_IMPLEMENTED) && (Compass_WAKEUP_ENABLED)) */


/* [] END OF FILE */
