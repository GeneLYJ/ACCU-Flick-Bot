/*******************************************************************************
* File Name: Sonar_2_PM.c
* Version 2.80
*
*  Description:
*     This file provides the power management source code to API for the
*     Timer.
*
*   Note:
*     None
*
*******************************************************************************
* Copyright 2008-2017, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
********************************************************************************/

#include "Sonar_2.h"

static Sonar_2_backupStruct Sonar_2_backup;


/*******************************************************************************
* Function Name: Sonar_2_SaveConfig
********************************************************************************
*
* Summary:
*     Save the current user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Sonar_2_backup:  Variables of this global structure are modified to
*  store the values of non retention configuration registers when Sleep() API is
*  called.
*
*******************************************************************************/
void Sonar_2_SaveConfig(void) 
{
    #if (!Sonar_2_UsingFixedFunction)
        Sonar_2_backup.TimerUdb = Sonar_2_ReadCounter();
        Sonar_2_backup.InterruptMaskValue = Sonar_2_STATUS_MASK;
        #if (Sonar_2_UsingHWCaptureCounter)
            Sonar_2_backup.TimerCaptureCounter = Sonar_2_ReadCaptureCount();
        #endif /* Back Up capture counter register  */

        #if(!Sonar_2_UDB_CONTROL_REG_REMOVED)
            Sonar_2_backup.TimerControlRegister = Sonar_2_ReadControlRegister();
        #endif /* Backup the enable state of the Timer component */
    #endif /* Backup non retention registers in UDB implementation. All fixed function registers are retention */
}


/*******************************************************************************
* Function Name: Sonar_2_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Sonar_2_backup:  Variables of this global structure are used to
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void Sonar_2_RestoreConfig(void) 
{   
    #if (!Sonar_2_UsingFixedFunction)

        Sonar_2_WriteCounter(Sonar_2_backup.TimerUdb);
        Sonar_2_STATUS_MASK =Sonar_2_backup.InterruptMaskValue;
        #if (Sonar_2_UsingHWCaptureCounter)
            Sonar_2_SetCaptureCount(Sonar_2_backup.TimerCaptureCounter);
        #endif /* Restore Capture counter register*/

        #if(!Sonar_2_UDB_CONTROL_REG_REMOVED)
            Sonar_2_WriteControlRegister(Sonar_2_backup.TimerControlRegister);
        #endif /* Restore the enable state of the Timer component */
    #endif /* Restore non retention registers in the UDB implementation only */
}


/*******************************************************************************
* Function Name: Sonar_2_Sleep
********************************************************************************
*
* Summary:
*     Stop and Save the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Sonar_2_backup.TimerEnableState:  Is modified depending on the
*  enable state of the block before entering sleep mode.
*
*******************************************************************************/
void Sonar_2_Sleep(void) 
{
    #if(!Sonar_2_UDB_CONTROL_REG_REMOVED)
        /* Save Counter's enable state */
        if(Sonar_2_CTRL_ENABLE == (Sonar_2_CONTROL & Sonar_2_CTRL_ENABLE))
        {
            /* Timer is enabled */
            Sonar_2_backup.TimerEnableState = 1u;
        }
        else
        {
            /* Timer is disabled */
            Sonar_2_backup.TimerEnableState = 0u;
        }
    #endif /* Back up enable state from the Timer control register */
    Sonar_2_Stop();
    Sonar_2_SaveConfig();
}


/*******************************************************************************
* Function Name: Sonar_2_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  Sonar_2_backup.enableState:  Is used to restore the enable state of
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void Sonar_2_Wakeup(void) 
{
    Sonar_2_RestoreConfig();
    #if(!Sonar_2_UDB_CONTROL_REG_REMOVED)
        if(Sonar_2_backup.TimerEnableState == 1u)
        {     /* Enable Timer's operation */
                Sonar_2_Enable();
        } /* Do nothing if Timer was disabled before */
    #endif /* Remove this code section if Control register is removed */
}


/* [] END OF FILE */
