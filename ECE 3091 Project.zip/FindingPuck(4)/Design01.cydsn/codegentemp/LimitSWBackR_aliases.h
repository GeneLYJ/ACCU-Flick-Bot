/*******************************************************************************
* File Name: LimitSWBackR.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_LimitSWBackR_ALIASES_H) /* Pins LimitSWBackR_ALIASES_H */
#define CY_PINS_LimitSWBackR_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define LimitSWBackR_0			(LimitSWBackR__0__PC)
#define LimitSWBackR_0_INTR	((uint16)((uint16)0x0001u << LimitSWBackR__0__SHIFT))

#define LimitSWBackR_INTR_ALL	 ((uint16)(LimitSWBackR_0_INTR))

#endif /* End Pins LimitSWBackR_ALIASES_H */


/* [] END OF FILE */
