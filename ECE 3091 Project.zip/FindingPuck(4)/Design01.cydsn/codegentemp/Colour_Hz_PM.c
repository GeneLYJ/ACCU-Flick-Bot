/*******************************************************************************
* File Name: Colour_Hz_PM.c  
* Version 3.0
*
*  Description:
*    This file provides the power management source code to API for the
*    Counter.  
*
*   Note:
*     None
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "Colour_Hz.h"

static Colour_Hz_backupStruct Colour_Hz_backup;


/*******************************************************************************
* Function Name: Colour_Hz_SaveConfig
********************************************************************************
* Summary:
*     Save the current user configuration
*
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  Colour_Hz_backup:  Variables of this global structure are modified to 
*  store the values of non retention configuration registers when Sleep() API is 
*  called.
*
*******************************************************************************/
void Colour_Hz_SaveConfig(void) 
{
    #if (!Colour_Hz_UsingFixedFunction)

        Colour_Hz_backup.CounterUdb = Colour_Hz_ReadCounter();

        #if(!Colour_Hz_ControlRegRemoved)
            Colour_Hz_backup.CounterControlRegister = Colour_Hz_ReadControlRegister();
        #endif /* (!Colour_Hz_ControlRegRemoved) */

    #endif /* (!Colour_Hz_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: Colour_Hz_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  Colour_Hz_backup:  Variables of this global structure are used to 
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void Colour_Hz_RestoreConfig(void) 
{      
    #if (!Colour_Hz_UsingFixedFunction)

       Colour_Hz_WriteCounter(Colour_Hz_backup.CounterUdb);

        #if(!Colour_Hz_ControlRegRemoved)
            Colour_Hz_WriteControlRegister(Colour_Hz_backup.CounterControlRegister);
        #endif /* (!Colour_Hz_ControlRegRemoved) */

    #endif /* (!Colour_Hz_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: Colour_Hz_Sleep
********************************************************************************
* Summary:
*     Stop and Save the user configuration
*
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  Colour_Hz_backup.enableState:  Is modified depending on the enable 
*  state of the block before entering sleep mode.
*
*******************************************************************************/
void Colour_Hz_Sleep(void) 
{
    #if(!Colour_Hz_ControlRegRemoved)
        /* Save Counter's enable state */
        if(Colour_Hz_CTRL_ENABLE == (Colour_Hz_CONTROL & Colour_Hz_CTRL_ENABLE))
        {
            /* Counter is enabled */
            Colour_Hz_backup.CounterEnableState = 1u;
        }
        else
        {
            /* Counter is disabled */
            Colour_Hz_backup.CounterEnableState = 0u;
        }
    #else
        Colour_Hz_backup.CounterEnableState = 1u;
        if(Colour_Hz_backup.CounterEnableState != 0u)
        {
            Colour_Hz_backup.CounterEnableState = 0u;
        }
    #endif /* (!Colour_Hz_ControlRegRemoved) */
    
    Colour_Hz_Stop();
    Colour_Hz_SaveConfig();
}


/*******************************************************************************
* Function Name: Colour_Hz_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*  
* Parameters:  
*  void
*
* Return: 
*  void
*
* Global variables:
*  Colour_Hz_backup.enableState:  Is used to restore the enable state of 
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void Colour_Hz_Wakeup(void) 
{
    Colour_Hz_RestoreConfig();
    #if(!Colour_Hz_ControlRegRemoved)
        if(Colour_Hz_backup.CounterEnableState == 1u)
        {
            /* Enable Counter's operation */
            Colour_Hz_Enable();
        } /* Do nothing if Counter was disabled before */    
    #endif /* (!Colour_Hz_ControlRegRemoved) */
    
}


/* [] END OF FILE */
