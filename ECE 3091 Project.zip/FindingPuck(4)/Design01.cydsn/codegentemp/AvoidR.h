/*******************************************************************************
* File Name: AvoidR.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_AvoidR_H) /* Pins AvoidR_H */
#define CY_PINS_AvoidR_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "AvoidR_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 AvoidR__PORT == 15 && ((AvoidR__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    AvoidR_Write(uint8 value);
void    AvoidR_SetDriveMode(uint8 mode);
uint8   AvoidR_ReadDataReg(void);
uint8   AvoidR_Read(void);
void    AvoidR_SetInterruptMode(uint16 position, uint16 mode);
uint8   AvoidR_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the AvoidR_SetDriveMode() function.
     *  @{
     */
        #define AvoidR_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define AvoidR_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define AvoidR_DM_RES_UP          PIN_DM_RES_UP
        #define AvoidR_DM_RES_DWN         PIN_DM_RES_DWN
        #define AvoidR_DM_OD_LO           PIN_DM_OD_LO
        #define AvoidR_DM_OD_HI           PIN_DM_OD_HI
        #define AvoidR_DM_STRONG          PIN_DM_STRONG
        #define AvoidR_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define AvoidR_MASK               AvoidR__MASK
#define AvoidR_SHIFT              AvoidR__SHIFT
#define AvoidR_WIDTH              1u

/* Interrupt constants */
#if defined(AvoidR__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in AvoidR_SetInterruptMode() function.
     *  @{
     */
        #define AvoidR_INTR_NONE      (uint16)(0x0000u)
        #define AvoidR_INTR_RISING    (uint16)(0x0001u)
        #define AvoidR_INTR_FALLING   (uint16)(0x0002u)
        #define AvoidR_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define AvoidR_INTR_MASK      (0x01u) 
#endif /* (AvoidR__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define AvoidR_PS                     (* (reg8 *) AvoidR__PS)
/* Data Register */
#define AvoidR_DR                     (* (reg8 *) AvoidR__DR)
/* Port Number */
#define AvoidR_PRT_NUM                (* (reg8 *) AvoidR__PRT) 
/* Connect to Analog Globals */                                                  
#define AvoidR_AG                     (* (reg8 *) AvoidR__AG)                       
/* Analog MUX bux enable */
#define AvoidR_AMUX                   (* (reg8 *) AvoidR__AMUX) 
/* Bidirectional Enable */                                                        
#define AvoidR_BIE                    (* (reg8 *) AvoidR__BIE)
/* Bit-mask for Aliased Register Access */
#define AvoidR_BIT_MASK               (* (reg8 *) AvoidR__BIT_MASK)
/* Bypass Enable */
#define AvoidR_BYP                    (* (reg8 *) AvoidR__BYP)
/* Port wide control signals */                                                   
#define AvoidR_CTL                    (* (reg8 *) AvoidR__CTL)
/* Drive Modes */
#define AvoidR_DM0                    (* (reg8 *) AvoidR__DM0) 
#define AvoidR_DM1                    (* (reg8 *) AvoidR__DM1)
#define AvoidR_DM2                    (* (reg8 *) AvoidR__DM2) 
/* Input Buffer Disable Override */
#define AvoidR_INP_DIS                (* (reg8 *) AvoidR__INP_DIS)
/* LCD Common or Segment Drive */
#define AvoidR_LCD_COM_SEG            (* (reg8 *) AvoidR__LCD_COM_SEG)
/* Enable Segment LCD */
#define AvoidR_LCD_EN                 (* (reg8 *) AvoidR__LCD_EN)
/* Slew Rate Control */
#define AvoidR_SLW                    (* (reg8 *) AvoidR__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define AvoidR_PRTDSI__CAPS_SEL       (* (reg8 *) AvoidR__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define AvoidR_PRTDSI__DBL_SYNC_IN    (* (reg8 *) AvoidR__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define AvoidR_PRTDSI__OE_SEL0        (* (reg8 *) AvoidR__PRTDSI__OE_SEL0) 
#define AvoidR_PRTDSI__OE_SEL1        (* (reg8 *) AvoidR__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define AvoidR_PRTDSI__OUT_SEL0       (* (reg8 *) AvoidR__PRTDSI__OUT_SEL0) 
#define AvoidR_PRTDSI__OUT_SEL1       (* (reg8 *) AvoidR__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define AvoidR_PRTDSI__SYNC_OUT       (* (reg8 *) AvoidR__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(AvoidR__SIO_CFG)
    #define AvoidR_SIO_HYST_EN        (* (reg8 *) AvoidR__SIO_HYST_EN)
    #define AvoidR_SIO_REG_HIFREQ     (* (reg8 *) AvoidR__SIO_REG_HIFREQ)
    #define AvoidR_SIO_CFG            (* (reg8 *) AvoidR__SIO_CFG)
    #define AvoidR_SIO_DIFF           (* (reg8 *) AvoidR__SIO_DIFF)
#endif /* (AvoidR__SIO_CFG) */

/* Interrupt Registers */
#if defined(AvoidR__INTSTAT)
    #define AvoidR_INTSTAT            (* (reg8 *) AvoidR__INTSTAT)
    #define AvoidR_SNAP               (* (reg8 *) AvoidR__SNAP)
    
	#define AvoidR_0_INTTYPE_REG 		(* (reg8 *) AvoidR__0__INTTYPE)
#endif /* (AvoidR__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_AvoidR_H */


/* [] END OF FILE */
