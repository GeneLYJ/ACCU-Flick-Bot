/*******************************************************************************
* File Name: AvoidL_isr.h
* Version 1.70
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_AvoidL_isr_H)
#define CY_ISR_AvoidL_isr_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void AvoidL_isr_Start(void);
void AvoidL_isr_StartEx(cyisraddress address);
void AvoidL_isr_Stop(void);

CY_ISR_PROTO(AvoidL_isr_Interrupt);

void AvoidL_isr_SetVector(cyisraddress address);
cyisraddress AvoidL_isr_GetVector(void);

void AvoidL_isr_SetPriority(uint8 priority);
uint8 AvoidL_isr_GetPriority(void);

void AvoidL_isr_Enable(void);
uint8 AvoidL_isr_GetState(void);
void AvoidL_isr_Disable(void);

void AvoidL_isr_SetPending(void);
void AvoidL_isr_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the AvoidL_isr ISR. */
#define AvoidL_isr_INTC_VECTOR            ((reg32 *) AvoidL_isr__INTC_VECT)

/* Address of the AvoidL_isr ISR priority. */
#define AvoidL_isr_INTC_PRIOR             ((reg8 *) AvoidL_isr__INTC_PRIOR_REG)

/* Priority of the AvoidL_isr interrupt. */
#define AvoidL_isr_INTC_PRIOR_NUMBER      AvoidL_isr__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable AvoidL_isr interrupt. */
#define AvoidL_isr_INTC_SET_EN            ((reg32 *) AvoidL_isr__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the AvoidL_isr interrupt. */
#define AvoidL_isr_INTC_CLR_EN            ((reg32 *) AvoidL_isr__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the AvoidL_isr interrupt state to pending. */
#define AvoidL_isr_INTC_SET_PD            ((reg32 *) AvoidL_isr__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the AvoidL_isr interrupt. */
#define AvoidL_isr_INTC_CLR_PD            ((reg32 *) AvoidL_isr__INTC_CLR_PD_REG)


#endif /* CY_ISR_AvoidL_isr_H */


/* [] END OF FILE */
