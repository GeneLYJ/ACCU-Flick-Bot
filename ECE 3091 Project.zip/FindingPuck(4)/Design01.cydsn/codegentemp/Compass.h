/*******************************************************************************
* File Name: Compass.h
* Version 3.50
*
* Description:
*  This file provides constants and parameter values for the I2C component.

*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_I2C_Compass_H)
#define CY_I2C_Compass_H

#include "cyfitter.h"
#include "cytypes.h"
#include "CyLib.h"

/* Check if required defines such as CY_PSOC5LP are available in cy_boot */
#if !defined (CY_PSOC5LP)
    #error Component I2C_v3_50 requires cy_boot v3.10 or later
#endif /* (CY_PSOC5LP) */


/***************************************
*   Conditional Compilation Parameters
****************************************/

#define Compass_IMPLEMENTATION     (1u)
#define Compass_MODE               (2u)
#define Compass_ENABLE_WAKEUP      (0u)
#define Compass_ADDR_DECODE        (1u)
#define Compass_UDB_INTRN_CLOCK    (0u)


/* I2C implementation enum */
#define Compass_UDB    (0x00u)
#define Compass_FF     (0x01u)

#define Compass_FF_IMPLEMENTED     (Compass_FF  == Compass_IMPLEMENTATION)
#define Compass_UDB_IMPLEMENTED    (Compass_UDB == Compass_IMPLEMENTATION)

#define Compass_UDB_INTRN_CLOCK_ENABLED    (Compass_UDB_IMPLEMENTED && \
                                                     (0u != Compass_UDB_INTRN_CLOCK))
/* I2C modes enum */
#define Compass_MODE_SLAVE                 (0x01u)
#define Compass_MODE_MASTER                (0x02u)
#define Compass_MODE_MULTI_MASTER          (0x06u)
#define Compass_MODE_MULTI_MASTER_SLAVE    (0x07u)
#define Compass_MODE_MULTI_MASTER_MASK     (0x04u)

#define Compass_MODE_SLAVE_ENABLED         (0u != (Compass_MODE_SLAVE  & Compass_MODE))
#define Compass_MODE_MASTER_ENABLED        (0u != (Compass_MODE_MASTER & Compass_MODE))
#define Compass_MODE_MULTI_MASTER_ENABLED  (0u != (Compass_MODE_MULTI_MASTER_MASK & \
                                                            Compass_MODE))
#define Compass_MODE_MULTI_MASTER_SLAVE_ENABLED    (Compass_MODE_MULTI_MASTER_SLAVE == \
                                                             Compass_MODE)

/* Address detection enum */
#define Compass_SW_DECODE      (0x00u)
#define Compass_HW_DECODE      (0x01u)

#define Compass_SW_ADRR_DECODE             (Compass_SW_DECODE == Compass_ADDR_DECODE)
#define Compass_HW_ADRR_DECODE             (Compass_HW_DECODE == Compass_ADDR_DECODE)

/* Wakeup enabled */
#define Compass_WAKEUP_ENABLED             (0u != Compass_ENABLE_WAKEUP)

/* Adds bootloader APIs to component */
#define Compass_BOOTLOADER_INTERFACE_ENABLED   (Compass_MODE_SLAVE_ENABLED && \
                                                            ((CYDEV_BOOTLOADER_IO_COMP == CyBtldr_Compass) || \
                                                             (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_Custom_Interface)))

/* Timeout functionality */
#define Compass_TIMEOUT_ENABLE             (0u)
#define Compass_TIMEOUT_SCL_TMOUT_ENABLE   (0u)
#define Compass_TIMEOUT_SDA_TMOUT_ENABLE   (0u)
#define Compass_TIMEOUT_PRESCALER_ENABLE   (0u)
#define Compass_TIMEOUT_IMPLEMENTATION     (0u)

/* Convert to boolean */
#define Compass_TIMEOUT_ENABLED            (0u != Compass_TIMEOUT_ENABLE)
#define Compass_TIMEOUT_SCL_TMOUT_ENABLED  (0u != Compass_TIMEOUT_SCL_TMOUT_ENABLE)
#define Compass_TIMEOUT_SDA_TMOUT_ENABLED  (0u != Compass_TIMEOUT_SDA_TMOUT_ENABLE)
#define Compass_TIMEOUT_PRESCALER_ENABLED  (0u != Compass_TIMEOUT_PRESCALER_ENABLE)

/* Timeout implementation enum. */
#define Compass_TIMEOUT_UDB    (0x00u)
#define Compass_TIMEOUT_FF     (0x01u)

#define Compass_TIMEOUT_FF_IMPLEMENTED     (Compass_TIMEOUT_FF  == \
                                                        Compass_TIMEOUT_IMPLEMENTATION)
#define Compass_TIMEOUT_UDB_IMPLEMENTED    (Compass_TIMEOUT_UDB == \
                                                        Compass_TIMEOUT_IMPLEMENTATION)

#define Compass_TIMEOUT_FF_ENABLED         (Compass_TIMEOUT_ENABLED && \
                                                     Compass_TIMEOUT_FF_IMPLEMENTED)

#define Compass_TIMEOUT_UDB_ENABLED        (Compass_TIMEOUT_ENABLED && \
                                                     Compass_TIMEOUT_UDB_IMPLEMENTED)

#define Compass_EXTERN_I2C_INTR_HANDLER    (0u)
#define Compass_EXTERN_TMOUT_INTR_HANDLER  (0u)

#define Compass_INTERN_I2C_INTR_HANDLER    (0u == Compass_EXTERN_I2C_INTR_HANDLER)
#define Compass_INTERN_TMOUT_INTR_HANDLER  (0u == Compass_EXTERN_TMOUT_INTR_HANDLER)


/***************************************
*       Type defines
***************************************/

/* Structure to save registers before go to sleep */
typedef struct
{
    uint8 enableState;

#if (Compass_FF_IMPLEMENTED)
    uint8 xcfg;
    uint8 cfg;
    uint8 addr;
    uint8 clkDiv1;
    uint8 clkDiv2;
#else
    uint8 control;
#endif /* (Compass_FF_IMPLEMENTED) */

#if (Compass_TIMEOUT_ENABLED)
    uint16 tmoutCfg;
    uint8  tmoutIntr;
#endif /* (Compass_TIMEOUT_ENABLED) */

} Compass_BACKUP_STRUCT;


/***************************************
*        Function Prototypes
***************************************/

void Compass_Init(void)                            ;
void Compass_Enable(void)                          ;

void Compass_Start(void)                           ;
void Compass_Stop(void)                            ;

#define Compass_EnableInt()        CyIntEnable      (Compass_ISR_NUMBER)
#define Compass_DisableInt()       CyIntDisable     (Compass_ISR_NUMBER)
#define Compass_ClearPendingInt()  CyIntClearPending(Compass_ISR_NUMBER)
#define Compass_SetPendingInt()    CyIntSetPending  (Compass_ISR_NUMBER)

void Compass_SaveConfig(void)                      ;
void Compass_Sleep(void)                           ;
void Compass_RestoreConfig(void)                   ;
void Compass_Wakeup(void)                          ;

/* I2C Master functions prototypes */
#if (Compass_MODE_MASTER_ENABLED)
    /* Read and Clear status functions */
    uint8 Compass_MasterStatus(void)                ;
    uint8 Compass_MasterClearStatus(void)           ;

    /* Interrupt based operation functions */
    uint8 Compass_MasterWriteBuf(uint8 slaveAddress, uint8 * wrData, uint8 cnt, uint8 mode) \
                                                            ;
    uint8 Compass_MasterReadBuf(uint8 slaveAddress, uint8 * rdData, uint8 cnt, uint8 mode) \
                                                            ;
    uint8 Compass_MasterGetReadBufSize(void)       ;
    uint8 Compass_MasterGetWriteBufSize(void)      ;
    void  Compass_MasterClearReadBuf(void)         ;
    void  Compass_MasterClearWriteBuf(void)        ;

    /* Manual operation functions */
    uint8 Compass_MasterSendStart(uint8 slaveAddress, uint8 R_nW) \
                                                            ;
    uint8 Compass_MasterSendRestart(uint8 slaveAddress, uint8 R_nW) \
                                                            ;
    uint8 Compass_MasterSendStop(void)             ;
    uint8 Compass_MasterWriteByte(uint8 theByte)   ;
    uint8 Compass_MasterReadByte(uint8 acknNak)    ;

#endif /* (Compass_MODE_MASTER_ENABLED) */

/* I2C Slave functions prototypes */
#if (Compass_MODE_SLAVE_ENABLED)
    /* Read and Clear status functions */
    uint8 Compass_SlaveStatus(void)                ;
    uint8 Compass_SlaveClearReadStatus(void)       ;
    uint8 Compass_SlaveClearWriteStatus(void)      ;

    void  Compass_SlaveSetAddress(uint8 address)   ;

    /* Interrupt based operation functions */
    void  Compass_SlaveInitReadBuf(uint8 * rdBuf, uint8 bufSize) \
                                                            ;
    void  Compass_SlaveInitWriteBuf(uint8 * wrBuf, uint8 bufSize) \
                                                            ;
    uint8 Compass_SlaveGetReadBufSize(void)        ;
    uint8 Compass_SlaveGetWriteBufSize(void)       ;
    void  Compass_SlaveClearReadBuf(void)          ;
    void  Compass_SlaveClearWriteBuf(void)         ;

    /* Communication bootloader I2C Slave APIs */
    #if defined(CYDEV_BOOTLOADER_IO_COMP) && (Compass_BOOTLOADER_INTERFACE_ENABLED)
        /* Physical layer functions */
        void     Compass_CyBtldrCommStart(void) CYSMALL \
                                                            ;
        void     Compass_CyBtldrCommStop(void)  CYSMALL \
                                                            ;
        void     Compass_CyBtldrCommReset(void) CYSMALL \
                                                            ;
        cystatus Compass_CyBtldrCommWrite(const uint8 pData[], uint16 size, uint16 * count, uint8 timeOut) \
                                                        CYSMALL ;
        cystatus Compass_CyBtldrCommRead(uint8 pData[], uint16 size, uint16 * count, uint8 timeOut)  CYSMALL \
                                                            ;

        #if (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_Compass)
            #define CyBtldrCommStart    Compass_CyBtldrCommStart
            #define CyBtldrCommStop     Compass_CyBtldrCommStop
            #define CyBtldrCommReset    Compass_CyBtldrCommReset
            #define CyBtldrCommWrite    Compass_CyBtldrCommWrite
            #define CyBtldrCommRead     Compass_CyBtldrCommRead
        #endif /* (CYDEV_BOOTLOADER_IO_COMP == CyBtldr_Compass) */

        /* Size of Read/Write buffers for I2C bootloader  */
        #define Compass_BTLDR_SIZEOF_READ_BUFFER   (0x80u)
        #define Compass_BTLDR_SIZEOF_WRITE_BUFFER  (0x80u)
        #define Compass_MIN_UNT16(a, b)            ( ((uint16)(a) < (b)) ? ((uint16) (a)) : ((uint16) (b)) )
        #define Compass_WAIT_1_MS                  (1u)

    #endif /* defined(CYDEV_BOOTLOADER_IO_COMP) && (Compass_BOOTLOADER_INTERFACE_ENABLED) */

#endif /* (Compass_MODE_SLAVE_ENABLED) */

/* Component interrupt handlers */
CY_ISR_PROTO(Compass_ISR);
#if ((Compass_FF_IMPLEMENTED) || (Compass_WAKEUP_ENABLED))
    CY_ISR_PROTO(Compass_WAKEUP_ISR);
#endif /* ((Compass_FF_IMPLEMENTED) || (Compass_WAKEUP_ENABLED)) */


/**********************************
*   Variable with external linkage
**********************************/

extern uint8 Compass_initVar;


/***************************************
*   Initial Parameter Constants
***************************************/

#define Compass_DATA_RATE          (100u)
#define Compass_DEFAULT_ADDR       (8u)
#define Compass_I2C_PAIR_SELECTED  (0u)

/* I2C pair enum */
#define Compass_I2C_PAIR_ANY   (0x01u) /* Any pins for I2C */
#define Compass_I2C_PAIR0      (0x01u) /* I2C0: (SCL = P12[4]) && (SCL = P12[5]) */
#define Compass_I2C_PAIR1      (0x02u) /* I2C1: (SCL = P12[0]) && (SDA = P12[1]) */

#define Compass_I2C1_SIO_PAIR  (Compass_I2C_PAIR1 == Compass_I2C_PAIR_SELECTED)
#define Compass_I2C0_SIO_PAIR  (Compass_I2C_PAIR0 == Compass_I2C_PAIR_SELECTED)


/***************************************
*            API Constants
***************************************/

/* Master/Slave control constants */
#define Compass_READ_XFER_MODE     (0x01u) /* Read */
#define Compass_WRITE_XFER_MODE    (0x00u) /* Write */
#define Compass_ACK_DATA           (0x01u) /* Send ACK */
#define Compass_NAK_DATA           (0x00u) /* Send NAK */
#define Compass_OVERFLOW_RETURN    (0xFFu) /* Send on bus in case of overflow */

#if (Compass_MODE_MASTER_ENABLED)
    /* "Mode" constants for MasterWriteBuf() or MasterReadBuf() function */
    #define Compass_MODE_COMPLETE_XFER     (0x00u) /* Full transfer with Start and Stop */
    #define Compass_MODE_REPEAT_START      (0x01u) /* Begin with a ReStart instead of a Start */
    #define Compass_MODE_NO_STOP           (0x02u) /* Complete the transfer without a Stop */

    /* Master status */
    #define Compass_MSTAT_CLEAR            (0x00u) /* Clear (initialize) status value */

    #define Compass_MSTAT_RD_CMPLT         (0x01u) /* Read complete */
    #define Compass_MSTAT_WR_CMPLT         (0x02u) /* Write complete */
    #define Compass_MSTAT_XFER_INP         (0x04u) /* Master transfer in progress */
    #define Compass_MSTAT_XFER_HALT        (0x08u) /* Transfer is halted */

    #define Compass_MSTAT_ERR_MASK         (0xF0u) /* Mask for all errors */
    #define Compass_MSTAT_ERR_SHORT_XFER   (0x10u) /* Master NAKed before end of packet */
    #define Compass_MSTAT_ERR_ADDR_NAK     (0x20u) /* Slave did not ACK */
    #define Compass_MSTAT_ERR_ARB_LOST     (0x40u) /* Master lost arbitration during communication */
    #define Compass_MSTAT_ERR_XFER         (0x80u) /* Error during transfer */

    /* Master API returns */
    #define Compass_MSTR_NO_ERROR          (0x00u) /* Function complete without error */
    #define Compass_MSTR_BUS_BUSY          (0x01u) /* Bus is busy, process not started */
    #define Compass_MSTR_NOT_READY         (0x02u) /* Master not Master on the bus or */
                                                            /*  Slave operation in progress */
    #define Compass_MSTR_ERR_LB_NAK        (0x03u) /* Last Byte Naked */
    #define Compass_MSTR_ERR_ARB_LOST      (0x04u) /* Master lost arbitration during communication */
    #define Compass_MSTR_ERR_ABORT_START_GEN  (0x05u) /* Master did not generate Start, the Slave */
                                                               /* was addressed before */

#endif /* (Compass_MODE_MASTER_ENABLED) */

#if (Compass_MODE_SLAVE_ENABLED)
    /* Slave Status Constants */
    #define Compass_SSTAT_RD_CMPLT     (0x01u) /* Read transfer complete */
    #define Compass_SSTAT_RD_BUSY      (0x02u) /* Read transfer in progress */
    #define Compass_SSTAT_RD_ERR_OVFL  (0x04u) /* Read overflow Error */
    #define Compass_SSTAT_RD_MASK      (0x0Fu) /* Read Status Mask */
    #define Compass_SSTAT_RD_NO_ERR    (0x00u) /* Read no Error */

    #define Compass_SSTAT_WR_CMPLT     (0x10u) /* Write transfer complete */
    #define Compass_SSTAT_WR_BUSY      (0x20u) /* Write transfer in progress */
    #define Compass_SSTAT_WR_ERR_OVFL  (0x40u) /* Write overflow Error */
    #define Compass_SSTAT_WR_MASK      (0xF0u) /* Write Status Mask  */
    #define Compass_SSTAT_WR_NO_ERR    (0x00u) /* Write no Error */

    #define Compass_SSTAT_RD_CLEAR     (0x0Du) /* Read Status clear */
    #define Compass_SSTAT_WR_CLEAR     (0xD0u) /* Write Status Clear */

#endif /* (Compass_MODE_SLAVE_ENABLED) */


/***************************************
*       I2C state machine constants
***************************************/

/* Default slave address states */
#define  Compass_SM_IDLE           (0x10u) /* Default state - IDLE */
#define  Compass_SM_EXIT_IDLE      (0x00u) /* Pass master and slave processing and go to IDLE */

/* Slave mode states */
#define  Compass_SM_SLAVE          (Compass_SM_IDLE) /* Any Slave state */
#define  Compass_SM_SL_WR_DATA     (0x11u) /* Master writes data to slave  */
#define  Compass_SM_SL_RD_DATA     (0x12u) /* Master reads data from slave */

/* Master mode states */
#define  Compass_SM_MASTER         (0x40u) /* Any master state */

#define  Compass_SM_MSTR_RD        (0x08u) /* Any master read state          */
#define  Compass_SM_MSTR_RD_ADDR   (0x49u) /* Master sends address with read */
#define  Compass_SM_MSTR_RD_DATA   (0x4Au) /* Master reads data              */

#define  Compass_SM_MSTR_WR        (0x04u) /* Any master read state           */
#define  Compass_SM_MSTR_WR_ADDR   (0x45u) /* Master sends address with write */
#define  Compass_SM_MSTR_WR_DATA   (0x46u) /* Master writes data              */

#define  Compass_SM_MSTR_HALT      (0x60u) /* Master waits for ReStart */

#define Compass_CHECK_SM_MASTER    (0u != (Compass_SM_MASTER & Compass_state))
#define Compass_CHECK_SM_SLAVE     (0u != (Compass_SM_SLAVE  & Compass_state))


/***************************************
*              Registers
***************************************/

#if (Compass_FF_IMPLEMENTED)
    /* Fixed Function registers */
    #define Compass_XCFG_REG           (*(reg8 *) Compass_I2C_FF__XCFG)
    #define Compass_XCFG_PTR           ( (reg8 *) Compass_I2C_FF__XCFG)

    #define Compass_ADDR_REG           (*(reg8 *) Compass_I2C_FF__ADR)
    #define Compass_ADDR_PTR           ( (reg8 *) Compass_I2C_FF__ADR)

    #define Compass_CFG_REG            (*(reg8 *) Compass_I2C_FF__CFG)
    #define Compass_CFG_PTR            ( (reg8 *) Compass_I2C_FF__CFG)

    #define Compass_CSR_REG            (*(reg8 *) Compass_I2C_FF__CSR)
    #define Compass_CSR_PTR            ( (reg8 *) Compass_I2C_FF__CSR)

    #define Compass_DATA_REG           (*(reg8 *) Compass_I2C_FF__D)
    #define Compass_DATA_PTR           ( (reg8 *) Compass_I2C_FF__D)

    #define Compass_MCSR_REG           (*(reg8 *) Compass_I2C_FF__MCSR)
    #define Compass_MCSR_PTR           ( (reg8 *) Compass_I2C_FF__MCSR)

    #define Compass_ACT_PWRMGR_REG     (*(reg8 *) Compass_I2C_FF__PM_ACT_CFG)
    #define Compass_ACT_PWRMGR_PTR     ( (reg8 *) Compass_I2C_FF__PM_ACT_CFG)
    #define Compass_ACT_PWR_EN         ( (uint8)  Compass_I2C_FF__PM_ACT_MSK)

    #define Compass_STBY_PWRMGR_REG    (*(reg8 *) Compass_I2C_FF__PM_STBY_CFG)
    #define Compass_STBY_PWRMGR_PTR    ( (reg8 *) Compass_I2C_FF__PM_STBY_CFG)
    #define Compass_STBY_PWR_EN        ( (uint8)  Compass_I2C_FF__PM_STBY_MSK)

    #define Compass_PWRSYS_CR1_REG     (*(reg8 *) CYREG_PWRSYS_CR1)
    #define Compass_PWRSYS_CR1_PTR     ( (reg8 *) CYREG_PWRSYS_CR1)

    #define Compass_CLKDIV1_REG    (*(reg8 *) Compass_I2C_FF__CLK_DIV1)
    #define Compass_CLKDIV1_PTR    ( (reg8 *) Compass_I2C_FF__CLK_DIV1)

    #define Compass_CLKDIV2_REG    (*(reg8 *) Compass_I2C_FF__CLK_DIV2)
    #define Compass_CLKDIV2_PTR    ( (reg8 *) Compass_I2C_FF__CLK_DIV2)

#else
    /* UDB implementation registers */
    #define Compass_CFG_REG \
            (*(reg8 *) Compass_bI2C_UDB_SyncCtl_CtrlReg__CONTROL_REG)
    #define Compass_CFG_PTR \
            ( (reg8 *) Compass_bI2C_UDB_SyncCtl_CtrlReg__CONTROL_REG)

    #define Compass_CSR_REG        (*(reg8 *) Compass_bI2C_UDB_StsReg__STATUS_REG)
    #define Compass_CSR_PTR        ( (reg8 *) Compass_bI2C_UDB_StsReg__STATUS_REG)

    #define Compass_INT_MASK_REG   (*(reg8 *) Compass_bI2C_UDB_StsReg__MASK_REG)
    #define Compass_INT_MASK_PTR   ( (reg8 *) Compass_bI2C_UDB_StsReg__MASK_REG)

    #define Compass_INT_ENABLE_REG (*(reg8 *) Compass_bI2C_UDB_StsReg__STATUS_AUX_CTL_REG)
    #define Compass_INT_ENABLE_PTR ( (reg8 *) Compass_bI2C_UDB_StsReg__STATUS_AUX_CTL_REG)

    #define Compass_DATA_REG       (*(reg8 *) Compass_bI2C_UDB_Shifter_u0__A0_REG)
    #define Compass_DATA_PTR       ( (reg8 *) Compass_bI2C_UDB_Shifter_u0__A0_REG)

    #define Compass_GO_REG         (*(reg8 *) Compass_bI2C_UDB_Shifter_u0__F1_REG)
    #define Compass_GO_PTR         ( (reg8 *) Compass_bI2C_UDB_Shifter_u0__F1_REG)

    #define Compass_GO_DONE_REG    (*(reg8 *) Compass_bI2C_UDB_Shifter_u0__A1_REG)
    #define Compass_GO_DONE_PTR    ( (reg8 *) Compass_bI2C_UDB_Shifter_u0__A1_REG)

    #define Compass_MCLK_PRD_REG   (*(reg8 *) Compass_bI2C_UDB_Master_ClkGen_u0__D0_REG)
    #define Compass_MCLK_PRD_PTR   ( (reg8 *) Compass_bI2C_UDB_Master_ClkGen_u0__D0_REG)

    #define Compass_MCLK_CMP_REG   (*(reg8 *) Compass_bI2C_UDB_Master_ClkGen_u0__D1_REG)
    #define Compass_MCLK_CMP_PTR   ( (reg8 *) Compass_bI2C_UDB_Master_ClkGen_u0__D1_REG)

    #if (Compass_MODE_SLAVE_ENABLED)
        #define Compass_ADDR_REG       (*(reg8 *) Compass_bI2C_UDB_Shifter_u0__D0_REG)
        #define Compass_ADDR_PTR       ( (reg8 *) Compass_bI2C_UDB_Shifter_u0__D0_REG)

        #define Compass_PERIOD_REG     (*(reg8 *) Compass_bI2C_UDB_Slave_BitCounter__PERIOD_REG)
        #define Compass_PERIOD_PTR     ( (reg8 *) Compass_bI2C_UDB_Slave_BitCounter__PERIOD_REG)

        #define Compass_COUNTER_REG    (*(reg8 *) Compass_bI2C_UDB_Slave_BitCounter__COUNT_REG)
        #define Compass_COUNTER_PTR    ( (reg8 *) Compass_bI2C_UDB_Slave_BitCounter__COUNT_REG)

        #define Compass_COUNTER_AUX_CTL_REG \
                                    (*(reg8 *) Compass_bI2C_UDB_Slave_BitCounter__CONTROL_AUX_CTL_REG)
        #define Compass_COUNTER_AUX_CTL_PTR \
                                    ( (reg8 *) Compass_bI2C_UDB_Slave_BitCounter__CONTROL_AUX_CTL_REG)

    #endif /* (Compass_MODE_SLAVE_ENABLED) */

#endif /* (Compass_FF_IMPLEMENTED) */


/***************************************
*        Registers Constants
***************************************/

/* Compass_I2C_IRQ */
#define Compass_ISR_NUMBER     ((uint8) Compass_I2C_IRQ__INTC_NUMBER)
#define Compass_ISR_PRIORITY   ((uint8) Compass_I2C_IRQ__INTC_PRIOR_NUM)

/* I2C Slave Data Register */
#define Compass_SLAVE_ADDR_MASK    (0x7Fu)
#define Compass_SLAVE_ADDR_SHIFT   (0x01u)
#define Compass_DATA_MASK          (0xFFu)
#define Compass_READ_FLAG          (0x01u)

/* Block reset constants */
#define Compass_CLEAR_REG          (0x00u)
#define Compass_BLOCK_RESET_DELAY  (2u)
#define Compass_FF_RESET_DELAY     (Compass_BLOCK_RESET_DELAY)
#define Compass_RESTORE_TIMEOUT    (255u)

#if (Compass_FF_IMPLEMENTED)
    /* XCFG I2C Extended Configuration Register */
    #define Compass_XCFG_CLK_EN        (0x80u) /* Enable gated clock to block */
    #define Compass_XCFG_I2C_ON        (0x40u) /* Enable I2C as wake up source*/
    #define Compass_XCFG_RDY_TO_SLEEP  (0x20u) /* I2C ready go to sleep */
    #define Compass_XCFG_FORCE_NACK    (0x10u) /* Force NACK all incoming transactions */
    #define Compass_XCFG_NO_BC_INT     (0x08u) /* No interrupt on byte complete */
    #define Compass_XCFG_BUF_MODE      (0x02u) /* Enable buffer mode */
    #define Compass_XCFG_HDWR_ADDR_EN  (0x01u) /* Enable Hardware address match */

    /* CFG I2C Configuration Register */
    #define Compass_CFG_SIO_SELECT     (0x80u) /* Pin Select for SCL/SDA lines */
    #define Compass_CFG_PSELECT        (0x40u) /* Pin Select */
    #define Compass_CFG_BUS_ERR_IE     (0x20u) /* Bus Error Interrupt Enable */
    #define Compass_CFG_STOP_IE        (0x10u) /* Enable Interrupt on STOP condition */
    #define Compass_CFG_CLK_RATE_MSK   (0x0Cu) /* Clock rate select */
    #define Compass_CFG_CLK_RATE_100   (0x00u) /* Clock rate select 100K */
    #define Compass_CFG_CLK_RATE_400   (0x04u) /* Clock rate select 400K */
    #define Compass_CFG_CLK_RATE_050   (0x08u) /* Clock rate select 50K  */
    #define Compass_CFG_CLK_RATE_RSVD  (0x0Cu) /* Clock rate select Invalid */
    #define Compass_CFG_EN_MSTR        (0x02u) /* Enable Master operation */
    #define Compass_CFG_EN_SLAVE       (0x01u) /* Enable Slave operation */

    #define Compass_CFG_CLK_RATE_LESS_EQUAL_50 (0x04u) /* Clock rate select <= 50kHz */
    #define Compass_CFG_CLK_RATE_GRATER_50     (0x00u) /* Clock rate select > 50kHz */

    /* CSR I2C Control and Status Register */
    #define Compass_CSR_BUS_ERROR      (0x80u) /* Active high when bus error has occurred */
    #define Compass_CSR_LOST_ARB       (0x40u) /* Set to 1 if lost arbitration in host mode */
    #define Compass_CSR_STOP_STATUS    (0x20u) /* Set if Stop has been detected */
    #define Compass_CSR_ACK            (0x10u) /* ACK response */
    #define Compass_CSR_NAK            (0x00u) /* NAK response */
    #define Compass_CSR_ADDRESS        (0x08u) /* Set in firmware 0 = status bit, 1 Address is slave */
    #define Compass_CSR_TRANSMIT       (0x04u) /* Set in firmware 1 = transmit, 0 = receive */
    #define Compass_CSR_LRB            (0x02u) /* Last received bit */
    #define Compass_CSR_LRB_ACK        (0x00u) /* Last received bit was an ACK */
    #define Compass_CSR_LRB_NAK        (0x02u) /* Last received bit was an NAK */
    #define Compass_CSR_BYTE_COMPLETE  (0x01u) /* Informs that last byte has been sent */
    #define Compass_CSR_STOP_GEN       (0x00u) /* Generate a stop condition */
    #define Compass_CSR_RDY_TO_RD      (0x00u) /* Set to receive mode */

    /* MCSR I2C Master Control and Status Register */
    #define Compass_MCSR_STOP_GEN      (0x10u) /* Firmware sets this bit to initiate a Stop condition */
    #define Compass_MCSR_BUS_BUSY      (0x08u) /* Status bit, Set at Start and cleared at Stop condition */
    #define Compass_MCSR_MSTR_MODE     (0x04u) /* Status bit, Set at Start and cleared at Stop condition */
    #define Compass_MCSR_RESTART_GEN   (0x02u) /* Firmware sets this bit to initiate a ReStart condition */
    #define Compass_MCSR_START_GEN     (0x01u) /* Firmware sets this bit to initiate a Start condition */

    /* PWRSYS_CR1 to handle Sleep */
    #define Compass_PWRSYS_CR1_I2C_REG_BACKUP  (0x04u) /* Enables, power to I2C regs while sleep */

#else
    /* CONTROL REG bits location */
    #define Compass_CTRL_START_SHIFT           (7u)
    #define Compass_CTRL_STOP_SHIFT            (6u)
    #define Compass_CTRL_RESTART_SHIFT         (5u)
    #define Compass_CTRL_NACK_SHIFT            (4u)
    #define Compass_CTRL_ANY_ADDRESS_SHIFT     (3u)
    #define Compass_CTRL_TRANSMIT_SHIFT        (2u)
    #define Compass_CTRL_ENABLE_MASTER_SHIFT   (1u)
    #define Compass_CTRL_ENABLE_SLAVE_SHIFT    (0u)
    #define Compass_CTRL_START_MASK            ((uint8) (0x01u << Compass_CTRL_START_SHIFT))
    #define Compass_CTRL_STOP_MASK             ((uint8) (0x01u << Compass_CTRL_STOP_SHIFT))
    #define Compass_CTRL_RESTART_MASK          ((uint8) (0x01u << Compass_CTRL_RESTART_SHIFT))
    #define Compass_CTRL_NACK_MASK             ((uint8) (0x01u << Compass_CTRL_NACK_SHIFT))
    #define Compass_CTRL_ANY_ADDRESS_MASK      ((uint8) (0x01u << Compass_CTRL_ANY_ADDRESS_SHIFT))
    #define Compass_CTRL_TRANSMIT_MASK         ((uint8) (0x01u << Compass_CTRL_TRANSMIT_SHIFT))
    #define Compass_CTRL_ENABLE_MASTER_MASK    ((uint8) (0x01u << Compass_CTRL_ENABLE_MASTER_SHIFT))
    #define Compass_CTRL_ENABLE_SLAVE_MASK     ((uint8) (0x01u << Compass_CTRL_ENABLE_SLAVE_SHIFT))

    /* STATUS REG bits location */
    #define Compass_STS_LOST_ARB_SHIFT         (6u)
    #define Compass_STS_STOP_SHIFT             (5u)
    #define Compass_STS_BUSY_SHIFT             (4u)
    #define Compass_STS_ADDR_SHIFT             (3u)
    #define Compass_STS_MASTER_MODE_SHIFT      (2u)
    #define Compass_STS_LRB_SHIFT              (1u)
    #define Compass_STS_BYTE_COMPLETE_SHIFT    (0u)
    #define Compass_STS_LOST_ARB_MASK          ((uint8) (0x01u << Compass_STS_LOST_ARB_SHIFT))
    #define Compass_STS_STOP_MASK              ((uint8) (0x01u << Compass_STS_STOP_SHIFT))
    #define Compass_STS_BUSY_MASK              ((uint8) (0x01u << Compass_STS_BUSY_SHIFT))
    #define Compass_STS_ADDR_MASK              ((uint8) (0x01u << Compass_STS_ADDR_SHIFT))
    #define Compass_STS_MASTER_MODE_MASK       ((uint8) (0x01u << Compass_STS_MASTER_MODE_SHIFT))
    #define Compass_STS_LRB_MASK               ((uint8) (0x01u << Compass_STS_LRB_SHIFT))
    #define Compass_STS_BYTE_COMPLETE_MASK     ((uint8) (0x01u << Compass_STS_BYTE_COMPLETE_SHIFT))

    /* AUX_CTL bits definition */
    #define Compass_COUNTER_ENABLE_MASK        (0x20u) /* Enable 7-bit counter */
    #define Compass_INT_ENABLE_MASK            (0x10u) /* Enable interrupt from status register */
    #define Compass_CNT7_ENABLE                (Compass_COUNTER_ENABLE_MASK)
    #define Compass_INTR_ENABLE                (Compass_INT_ENABLE_MASK)

#endif /* (Compass_FF_IMPLEMENTED) */


/***************************************
*        Marco
***************************************/

/* ACK and NACK for data and address checks */
#define Compass_CHECK_ADDR_ACK(csr)    ((Compass_CSR_LRB_ACK | Compass_CSR_ADDRESS) == \
                                                 ((Compass_CSR_LRB    | Compass_CSR_ADDRESS) &  \
                                                  (csr)))


#define Compass_CHECK_ADDR_NAK(csr)    ((Compass_CSR_LRB_NAK | Compass_CSR_ADDRESS) == \
                                                 ((Compass_CSR_LRB    | Compass_CSR_ADDRESS) &  \
                                                  (csr)))

#define Compass_CHECK_DATA_ACK(csr)    (0u == ((csr) & Compass_CSR_LRB_NAK))

/* MCSR conditions check */
#define Compass_CHECK_BUS_FREE(mcsr)       (0u == ((mcsr) & Compass_MCSR_BUS_BUSY))
#define Compass_CHECK_MASTER_MODE(mcsr)    (0u != ((mcsr) & Compass_MCSR_MSTR_MODE))

/* CSR conditions check */
#define Compass_WAIT_BYTE_COMPLETE(csr)    (0u == ((csr) & Compass_CSR_BYTE_COMPLETE))
#define Compass_WAIT_STOP_COMPLETE(csr)    (0u == ((csr) & (Compass_CSR_BYTE_COMPLETE | \
                                                                     Compass_CSR_STOP_STATUS)))
#define Compass_CHECK_BYTE_COMPLETE(csr)   (0u != ((csr) & Compass_CSR_BYTE_COMPLETE))
#define Compass_CHECK_STOP_STS(csr)        (0u != ((csr) & Compass_CSR_STOP_STATUS))
#define Compass_CHECK_LOST_ARB(csr)        (0u != ((csr) & Compass_CSR_LOST_ARB))
#define Compass_CHECK_ADDRESS_STS(csr)     (0u != ((csr) & Compass_CSR_ADDRESS))

/* Software start and end of transaction check */
#define Compass_CHECK_RESTART(mstrCtrl)    (0u != ((mstrCtrl) & Compass_MODE_REPEAT_START))
#define Compass_CHECK_NO_STOP(mstrCtrl)    (0u != ((mstrCtrl) & Compass_MODE_NO_STOP))

/* Send read or write completion depends on state */
#define Compass_GET_MSTAT_CMPLT ((0u != (Compass_state & Compass_SM_MSTR_RD)) ? \
                                                 (Compass_MSTAT_RD_CMPLT) : (Compass_MSTAT_WR_CMPLT))

/* Returns 7-bit slave address */
#define Compass_GET_SLAVE_ADDR(dataReg)   (((dataReg) >> Compass_SLAVE_ADDR_SHIFT) & \
                                                                  Compass_SLAVE_ADDR_MASK)

#if (Compass_FF_IMPLEMENTED)
    /* Check enable of module */
    #define Compass_I2C_ENABLE_REG     (Compass_ACT_PWRMGR_REG)
    #define Compass_IS_I2C_ENABLE(reg) (0u != ((reg) & Compass_ACT_PWR_EN))
    #define Compass_IS_ENABLED         (0u != (Compass_ACT_PWRMGR_REG & Compass_ACT_PWR_EN))

    #define Compass_CHECK_PWRSYS_I2C_BACKUP    (0u != (Compass_PWRSYS_CR1_I2C_REG_BACKUP & \
                                                                Compass_PWRSYS_CR1_REG))

    /* Check start condition generation */
    #define Compass_CHECK_START_GEN(mcsr)  ((0u != ((mcsr) & Compass_MCSR_START_GEN)) && \
                                                     (0u == ((mcsr) & Compass_MCSR_MSTR_MODE)))

    #define Compass_CLEAR_START_GEN        do{ \
                                                        Compass_MCSR_REG &=                                   \
                                                                           ((uint8) ~Compass_MCSR_START_GEN); \
                                                    }while(0)

    /* Stop interrupt */
    #define Compass_ENABLE_INT_ON_STOP     do{ \
                                                        Compass_CFG_REG |= Compass_CFG_STOP_IE; \
                                                    }while(0)

    #define Compass_DISABLE_INT_ON_STOP    do{ \
                                                        Compass_CFG_REG &=                                 \
                                                                           ((uint8) ~Compass_CFG_STOP_IE); \
                                                    }while(0)

    /* Transmit data */
    #define Compass_TRANSMIT_DATA          do{ \
                                                        Compass_CSR_REG = Compass_CSR_TRANSMIT; \
                                                    }while(0)

    #define Compass_ACK_AND_TRANSMIT       do{ \
                                                        Compass_CSR_REG = (Compass_CSR_ACK |      \
                                                                                    Compass_CSR_TRANSMIT); \
                                                    }while(0)

    #define Compass_NAK_AND_TRANSMIT       do{ \
                                                        Compass_CSR_REG = Compass_CSR_NAK; \
                                                    }while(0)

    /* Special case: udb needs to ack, ff needs to nak */
    #define Compass_ACKNAK_AND_TRANSMIT    do{ \
                                                        Compass_CSR_REG  = (Compass_CSR_NAK |      \
                                                                                     Compass_CSR_TRANSMIT); \
                                                    }while(0)
    /* Receive data */
    #define Compass_ACK_AND_RECEIVE        do{ \
                                                        Compass_CSR_REG = Compass_CSR_ACK; \
                                                    }while(0)

    #define Compass_NAK_AND_RECEIVE        do{ \
                                                        Compass_CSR_REG = Compass_CSR_NAK; \
                                                    }while(0)

    #define Compass_READY_TO_READ          do{ \
                                                        Compass_CSR_REG = Compass_CSR_RDY_TO_RD; \
                                                    }while(0)

    /* Release bus after lost arbitration */
    #define Compass_BUS_RELEASE    Compass_READY_TO_READ

    /* Master Start/ReStart/Stop conditions generation */
    #define Compass_GENERATE_START         do{ \
                                                        Compass_MCSR_REG = Compass_MCSR_START_GEN; \
                                                    }while(0)

    #define Compass_GENERATE_RESTART \
                    do{                       \
                        Compass_MCSR_REG = (Compass_MCSR_RESTART_GEN | \
                                                     Compass_MCSR_STOP_GEN);    \
                        Compass_CSR_REG  = Compass_CSR_TRANSMIT;       \
                    }while(0)

    #define Compass_GENERATE_STOP \
                    do{                    \
                        Compass_MCSR_REG = Compass_MCSR_STOP_GEN; \
                        Compass_CSR_REG  = Compass_CSR_TRANSMIT;  \
                    }while(0)

    /* Master manual APIs compatible defines */
    #define Compass_GENERATE_START_MANUAL      Compass_GENERATE_START
    #define Compass_GENERATE_RESTART_MANUAL    Compass_GENERATE_RESTART
    #define Compass_GENERATE_STOP_MANUAL       Compass_GENERATE_STOP
    #define Compass_TRANSMIT_DATA_MANUAL       Compass_TRANSMIT_DATA
    #define Compass_READY_TO_READ_MANUAL       Compass_READY_TO_READ
    #define Compass_ACK_AND_RECEIVE_MANUAL     Compass_ACK_AND_RECEIVE
    #define Compass_BUS_RELEASE_MANUAL         Compass_BUS_RELEASE

#else

    /* Masks to enable interrupts from Status register */
    #define Compass_STOP_IE_MASK           (Compass_STS_STOP_MASK)
    #define Compass_BYTE_COMPLETE_IE_MASK  (Compass_STS_BYTE_COMPLETE_MASK)

    /* FF compatibility: CSR register bit-fields */
    #define Compass_CSR_LOST_ARB       (Compass_STS_LOST_ARB_MASK)
    #define Compass_CSR_STOP_STATUS    (Compass_STS_STOP_MASK)
    #define Compass_CSR_BUS_ERROR      (0x00u)
    #define Compass_CSR_ADDRESS        (Compass_STS_ADDR_MASK)
    #define Compass_CSR_TRANSMIT       (Compass_CTRL_TRANSMIT_MASK)
    #define Compass_CSR_LRB            (Compass_STS_LRB_MASK)
    #define Compass_CSR_LRB_NAK        (Compass_STS_LRB_MASK)
    #define Compass_CSR_LRB_ACK        (0x00u)
    #define Compass_CSR_BYTE_COMPLETE  (Compass_STS_BYTE_COMPLETE_MASK)

    /* FF compatibility: MCSR registers bit-fields */
    #define Compass_MCSR_REG           (Compass_CSR_REG)  /* UDB incorporates master and slave regs */
    #define Compass_MCSR_BUS_BUSY      (Compass_STS_BUSY_MASK)      /* Is bus is busy               */
    #define Compass_MCSR_START_GEN     (Compass_CTRL_START_MASK)    /* Generate Start condition     */
    #define Compass_MCSR_RESTART_GEN   (Compass_CTRL_RESTART_MASK)  /* Generates RESTART condition  */
    #define Compass_MCSR_MSTR_MODE     (Compass_STS_MASTER_MODE_MASK)/* Define if active Master     */

    /* Data to write into TX FIFO to release FSM */
    #define Compass_PREPARE_TO_RELEASE (0xFFu)
    #define Compass_RELEASE_FSM        (0x00u)

    /* Define release command done: history of byte complete status is cleared */
    #define Compass_WAIT_RELEASE_CMD_DONE  (Compass_RELEASE_FSM != Compass_GO_DONE_REG)

    /* Check enable of module */
    #define Compass_I2C_ENABLE_REG     (Compass_CFG_REG)
    #define Compass_IS_I2C_ENABLE(reg) ((0u != ((reg) & Compass_ENABLE_MASTER)) || \
                                                 (0u != ((reg) & Compass_ENABLE_SLAVE)))

    #define Compass_IS_ENABLED         (0u != (Compass_CFG_REG & Compass_ENABLE_MS))

    /* Check start condition generation */
    #define Compass_CHECK_START_GEN(mcsr)  ((0u != (Compass_CFG_REG &        \
                                                             Compass_MCSR_START_GEN)) \
                                                    &&                                         \
                                                    (0u == ((mcsr) & Compass_MCSR_MSTR_MODE)))

    #define Compass_CLEAR_START_GEN        do{ \
                                                        Compass_CFG_REG &=                 \
                                                        ((uint8) ~Compass_MCSR_START_GEN); \
                                                    }while(0)

    /* Stop interrupt */
    #define Compass_ENABLE_INT_ON_STOP     do{ \
                                                       Compass_INT_MASK_REG |= Compass_STOP_IE_MASK; \
                                                    }while(0)

    #define Compass_DISABLE_INT_ON_STOP    do{ \
                                                        Compass_INT_MASK_REG &=                               \
                                                                             ((uint8) ~Compass_STOP_IE_MASK); \
                                                    }while(0)

    /* Transmit data */
    #define Compass_TRANSMIT_DATA \
                                    do{    \
                                        Compass_CFG_REG     = (Compass_CTRL_TRANSMIT_MASK | \
                                                                       Compass_CTRL_DEFAULT);        \
                                        Compass_GO_DONE_REG = Compass_PREPARE_TO_RELEASE;   \
                                        Compass_GO_REG      = Compass_RELEASE_FSM;          \
                                    }while(0)

    #define Compass_ACK_AND_TRANSMIT   Compass_TRANSMIT_DATA

    #define Compass_NAK_AND_TRANSMIT \
                                        do{   \
                                            Compass_CFG_REG     = (Compass_CTRL_NACK_MASK     | \
                                                                            Compass_CTRL_TRANSMIT_MASK | \
                                                                            Compass_CTRL_DEFAULT);       \
                                            Compass_GO_DONE_REG = Compass_PREPARE_TO_RELEASE;   \
                                            Compass_GO_REG      = Compass_RELEASE_FSM;          \
                                        }while(0)

    /* Receive data */
    #define Compass_READY_TO_READ  \
                                        do{ \
                                            Compass_CFG_REG     = Compass_CTRL_DEFAULT;       \
                                            Compass_GO_DONE_REG = Compass_PREPARE_TO_RELEASE; \
                                            Compass_GO_REG      = Compass_RELEASE_FSM;       \
                                        }while(0)

    #define Compass_ACK_AND_RECEIVE    Compass_READY_TO_READ

    /* Release bus after arbitration is lost */
    #define Compass_BUS_RELEASE    Compass_READY_TO_READ

    #define Compass_NAK_AND_RECEIVE \
                                        do{  \
                                            Compass_CFG_REG     = (Compass_CTRL_NACK_MASK |   \
                                                                            Compass_CTRL_DEFAULT);     \
                                            Compass_GO_DONE_REG = Compass_PREPARE_TO_RELEASE; \
                                            Compass_GO_REG      = Compass_RELEASE_FSM;       \
                                        }while(0)

    /* Master condition generation */
    #define Compass_GENERATE_START \
                                        do{ \
                                            Compass_CFG_REG     = (Compass_CTRL_START_MASK |  \
                                                                            Compass_CTRL_DEFAULT);     \
                                            Compass_GO_DONE_REG = Compass_PREPARE_TO_RELEASE; \
                                            Compass_GO_REG      = Compass_RELEASE_FSM;       \
                                        }while(0)

    #define Compass_GENERATE_RESTART \
                                        do{   \
                                            Compass_CFG_REG     = (Compass_CTRL_RESTART_MASK | \
                                                                            Compass_CTRL_NACK_MASK    | \
                                                                            Compass_CTRL_DEFAULT);      \
                                            Compass_GO_DONE_REG = Compass_PREPARE_TO_RELEASE;  \
                                            Compass_GO_REG  =     Compass_RELEASE_FSM;         \
                                        }while(0)

    #define Compass_GENERATE_STOP  \
                                        do{ \
                                            Compass_CFG_REG    = (Compass_CTRL_NACK_MASK |    \
                                                                           Compass_CTRL_STOP_MASK |    \
                                                                           Compass_CTRL_DEFAULT);      \
                                            Compass_GO_DONE_REG = Compass_PREPARE_TO_RELEASE; \
                                            Compass_GO_REG      = Compass_RELEASE_FSM;        \
                                        }while(0)

    /* Master manual APIs compatible macros */
    /* These macros wait until byte complete history is cleared after command issued */
    #define Compass_GENERATE_START_MANUAL \
                                        do{ \
                                            Compass_GENERATE_START;                  \
                                            /* Wait until byte complete history is cleared */ \
                                            while(Compass_WAIT_RELEASE_CMD_DONE)     \
                                            {                                                 \
                                            }                                                 \
                                        }while(0)
                                        
    #define Compass_GENERATE_RESTART_MANUAL \
                                        do{          \
                                            Compass_GENERATE_RESTART;                \
                                            /* Wait until byte complete history is cleared */ \
                                            while(Compass_WAIT_RELEASE_CMD_DONE)     \
                                            {                                                 \
                                            }                                                 \
                                        }while(0)

    #define Compass_GENERATE_STOP_MANUAL \
                                        do{       \
                                            Compass_GENERATE_STOP;                   \
                                            /* Wait until byte complete history is cleared */ \
                                            while(Compass_WAIT_RELEASE_CMD_DONE)     \
                                            {                                                 \
                                            }                                                 \
                                        }while(0)

    #define Compass_TRANSMIT_DATA_MANUAL \
                                        do{       \
                                            Compass_TRANSMIT_DATA;                   \
                                            /* Wait until byte complete history is cleared */ \
                                            while(Compass_WAIT_RELEASE_CMD_DONE)     \
                                            {                                                 \
                                            }                                                 \
                                        }while(0)

    #define Compass_READY_TO_READ_MANUAL \
                                        do{       \
                                            Compass_READY_TO_READ;                   \
                                            /* Wait until byte complete history is cleared */ \
                                            while(Compass_WAIT_RELEASE_CMD_DONE)     \
                                            {                                                 \
                                            }                                                 \
                                        }while(0)

    #define Compass_ACK_AND_RECEIVE_MANUAL \
                                        do{         \
                                            Compass_ACK_AND_RECEIVE;                 \
                                            /* Wait until byte complete history is cleared */ \
                                            while(Compass_WAIT_RELEASE_CMD_DONE)     \
                                            {                                                 \
                                            }                                                 \
                                        }while(0)

    #define Compass_BUS_RELEASE_MANUAL Compass_READY_TO_READ_MANUAL

#endif /* (Compass_FF_IMPLEMENTED) */


/***************************************
*     Default register init constants
***************************************/

#define Compass_DISABLE    (0u)
#define Compass_ENABLE     (1u)

#if (Compass_FF_IMPLEMENTED)
    /* Compass_XCFG_REG: bits definition */
    #define Compass_DEFAULT_XCFG_HW_ADDR_EN ((Compass_HW_ADRR_DECODE) ? \
                                                        (Compass_XCFG_HDWR_ADDR_EN) : (0u))

    #define Compass_DEFAULT_XCFG_I2C_ON    ((Compass_WAKEUP_ENABLED) ? \
                                                        (Compass_XCFG_I2C_ON) : (0u))


    #define Compass_DEFAULT_CFG_SIO_SELECT ((Compass_I2C1_SIO_PAIR) ? \
                                                        (Compass_CFG_SIO_SELECT) : (0u))


    /* Compass_CFG_REG: bits definition */
    #define Compass_DEFAULT_CFG_PSELECT    ((Compass_WAKEUP_ENABLED) ? \
                                                        (Compass_CFG_PSELECT) : (0u))

    #define Compass_DEFAULT_CLK_RATE0  ((Compass_DATA_RATE <= 50u) ?        \
                                                    (Compass_CFG_CLK_RATE_050) :     \
                                                    ((Compass_DATA_RATE <= 100u) ?   \
                                                        (Compass_CFG_CLK_RATE_100) : \
                                                        (Compass_CFG_CLK_RATE_400)))

    #define Compass_DEFAULT_CLK_RATE1  ((Compass_DATA_RATE <= 50u) ?           \
                                                 (Compass_CFG_CLK_RATE_LESS_EQUAL_50) : \
                                                 (Compass_CFG_CLK_RATE_GRATER_50))

    #define Compass_DEFAULT_CLK_RATE   (Compass_DEFAULT_CLK_RATE1)


    #define Compass_ENABLE_MASTER      ((Compass_MODE_MASTER_ENABLED) ? \
                                                 (Compass_CFG_EN_MSTR) : (0u))

    #define Compass_ENABLE_SLAVE       ((Compass_MODE_SLAVE_ENABLED) ? \
                                                 (Compass_CFG_EN_SLAVE) : (0u))

    #define Compass_ENABLE_MS      (Compass_ENABLE_MASTER | Compass_ENABLE_SLAVE)


    /* Compass_DEFAULT_XCFG_REG */
    #define Compass_DEFAULT_XCFG   (Compass_XCFG_CLK_EN         | \
                                             Compass_DEFAULT_XCFG_I2C_ON | \
                                             Compass_DEFAULT_XCFG_HW_ADDR_EN)

    /* Compass_DEFAULT_CFG_REG */
    #define Compass_DEFAULT_CFG    (Compass_DEFAULT_CFG_SIO_SELECT | \
                                             Compass_DEFAULT_CFG_PSELECT    | \
                                             Compass_DEFAULT_CLK_RATE       | \
                                             Compass_ENABLE_MASTER          | \
                                             Compass_ENABLE_SLAVE)

    /*Compass_DEFAULT_DIVIDE_FACTOR_REG */
    #define Compass_DEFAULT_DIVIDE_FACTOR  ((uint16) 15u)

#else
    /* Compass_CFG_REG: bits definition  */
    #define Compass_ENABLE_MASTER  ((Compass_MODE_MASTER_ENABLED) ? \
                                             (Compass_CTRL_ENABLE_MASTER_MASK) : (0u))

    #define Compass_ENABLE_SLAVE   ((Compass_MODE_SLAVE_ENABLED) ? \
                                             (Compass_CTRL_ENABLE_SLAVE_MASK) : (0u))

    #define Compass_ENABLE_MS      (Compass_ENABLE_MASTER | Compass_ENABLE_SLAVE)


    #define Compass_DEFAULT_CTRL_ANY_ADDR   ((Compass_HW_ADRR_DECODE) ? \
                                                      (0u) : (Compass_CTRL_ANY_ADDRESS_MASK))

    /* Compass_DEFAULT_CFG_REG */
    #define Compass_DEFAULT_CFG    (Compass_DEFAULT_CTRL_ANY_ADDR)

    /* All CTRL default bits to be used in macro */
    #define Compass_CTRL_DEFAULT   (Compass_DEFAULT_CTRL_ANY_ADDR | Compass_ENABLE_MS)

    /* Master clock generator: d0 and d1 */
    #define Compass_MCLK_PERIOD_VALUE  (0x0Fu)
    #define Compass_MCLK_COMPARE_VALUE (0x08u)

    /* Slave bit-counter: control period */
    #define Compass_PERIOD_VALUE       (0x07u)

    /* Compass_DEFAULT_INT_MASK */
    #define Compass_DEFAULT_INT_MASK   (Compass_BYTE_COMPLETE_IE_MASK)

    /* Compass_DEFAULT_MCLK_PRD_REG */
    #define Compass_DEFAULT_MCLK_PRD   (Compass_MCLK_PERIOD_VALUE)

    /* Compass_DEFAULT_MCLK_CMP_REG */
    #define Compass_DEFAULT_MCLK_CMP   (Compass_MCLK_COMPARE_VALUE)

    /* Compass_DEFAULT_PERIOD_REG */
    #define Compass_DEFAULT_PERIOD     (Compass_PERIOD_VALUE)

#endif /* (Compass_FF_IMPLEMENTED) */


/***************************************
* The following code is DEPRECATED and
* should not be used in new projects.
***************************************/

#define Compass_SSTAT_RD_ERR       (0x08u)
#define Compass_SSTAT_WR_ERR       (0x80u)
#define Compass_MSTR_SLAVE_BUSY    (Compass_MSTR_NOT_READY)
#define Compass_MSTAT_ERR_BUF_OVFL (0x80u)
#define Compass_SSTAT_RD_CMPT      (Compass_SSTAT_RD_CMPLT)
#define Compass_SSTAT_WR_CMPT      (Compass_SSTAT_WR_CMPLT)
#define Compass_MODE_MULTI_MASTER_ENABLE    (Compass_MODE_MULTI_MASTER_MASK)
#define Compass_DATA_RATE_50       (50u)
#define Compass_DATA_RATE_100      (100u)
#define Compass_DEV_MASK           (0xF0u)
#define Compass_SM_SL_STOP         (0x14u)
#define Compass_SM_MASTER_IDLE     (0x40u)
#define Compass_HDWR_DECODE        (0x01u)

#endif /* CY_I2C_Compass_H */


/* [] END OF FILE */
