/*******************************************************************************
* File Name: AvoidL.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_AvoidL_H) /* Pins AvoidL_H */
#define CY_PINS_AvoidL_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "AvoidL_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 AvoidL__PORT == 15 && ((AvoidL__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    AvoidL_Write(uint8 value);
void    AvoidL_SetDriveMode(uint8 mode);
uint8   AvoidL_ReadDataReg(void);
uint8   AvoidL_Read(void);
void    AvoidL_SetInterruptMode(uint16 position, uint16 mode);
uint8   AvoidL_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the AvoidL_SetDriveMode() function.
     *  @{
     */
        #define AvoidL_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define AvoidL_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define AvoidL_DM_RES_UP          PIN_DM_RES_UP
        #define AvoidL_DM_RES_DWN         PIN_DM_RES_DWN
        #define AvoidL_DM_OD_LO           PIN_DM_OD_LO
        #define AvoidL_DM_OD_HI           PIN_DM_OD_HI
        #define AvoidL_DM_STRONG          PIN_DM_STRONG
        #define AvoidL_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define AvoidL_MASK               AvoidL__MASK
#define AvoidL_SHIFT              AvoidL__SHIFT
#define AvoidL_WIDTH              1u

/* Interrupt constants */
#if defined(AvoidL__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in AvoidL_SetInterruptMode() function.
     *  @{
     */
        #define AvoidL_INTR_NONE      (uint16)(0x0000u)
        #define AvoidL_INTR_RISING    (uint16)(0x0001u)
        #define AvoidL_INTR_FALLING   (uint16)(0x0002u)
        #define AvoidL_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define AvoidL_INTR_MASK      (0x01u) 
#endif /* (AvoidL__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define AvoidL_PS                     (* (reg8 *) AvoidL__PS)
/* Data Register */
#define AvoidL_DR                     (* (reg8 *) AvoidL__DR)
/* Port Number */
#define AvoidL_PRT_NUM                (* (reg8 *) AvoidL__PRT) 
/* Connect to Analog Globals */                                                  
#define AvoidL_AG                     (* (reg8 *) AvoidL__AG)                       
/* Analog MUX bux enable */
#define AvoidL_AMUX                   (* (reg8 *) AvoidL__AMUX) 
/* Bidirectional Enable */                                                        
#define AvoidL_BIE                    (* (reg8 *) AvoidL__BIE)
/* Bit-mask for Aliased Register Access */
#define AvoidL_BIT_MASK               (* (reg8 *) AvoidL__BIT_MASK)
/* Bypass Enable */
#define AvoidL_BYP                    (* (reg8 *) AvoidL__BYP)
/* Port wide control signals */                                                   
#define AvoidL_CTL                    (* (reg8 *) AvoidL__CTL)
/* Drive Modes */
#define AvoidL_DM0                    (* (reg8 *) AvoidL__DM0) 
#define AvoidL_DM1                    (* (reg8 *) AvoidL__DM1)
#define AvoidL_DM2                    (* (reg8 *) AvoidL__DM2) 
/* Input Buffer Disable Override */
#define AvoidL_INP_DIS                (* (reg8 *) AvoidL__INP_DIS)
/* LCD Common or Segment Drive */
#define AvoidL_LCD_COM_SEG            (* (reg8 *) AvoidL__LCD_COM_SEG)
/* Enable Segment LCD */
#define AvoidL_LCD_EN                 (* (reg8 *) AvoidL__LCD_EN)
/* Slew Rate Control */
#define AvoidL_SLW                    (* (reg8 *) AvoidL__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define AvoidL_PRTDSI__CAPS_SEL       (* (reg8 *) AvoidL__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define AvoidL_PRTDSI__DBL_SYNC_IN    (* (reg8 *) AvoidL__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define AvoidL_PRTDSI__OE_SEL0        (* (reg8 *) AvoidL__PRTDSI__OE_SEL0) 
#define AvoidL_PRTDSI__OE_SEL1        (* (reg8 *) AvoidL__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define AvoidL_PRTDSI__OUT_SEL0       (* (reg8 *) AvoidL__PRTDSI__OUT_SEL0) 
#define AvoidL_PRTDSI__OUT_SEL1       (* (reg8 *) AvoidL__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define AvoidL_PRTDSI__SYNC_OUT       (* (reg8 *) AvoidL__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(AvoidL__SIO_CFG)
    #define AvoidL_SIO_HYST_EN        (* (reg8 *) AvoidL__SIO_HYST_EN)
    #define AvoidL_SIO_REG_HIFREQ     (* (reg8 *) AvoidL__SIO_REG_HIFREQ)
    #define AvoidL_SIO_CFG            (* (reg8 *) AvoidL__SIO_CFG)
    #define AvoidL_SIO_DIFF           (* (reg8 *) AvoidL__SIO_DIFF)
#endif /* (AvoidL__SIO_CFG) */

/* Interrupt Registers */
#if defined(AvoidL__INTSTAT)
    #define AvoidL_INTSTAT            (* (reg8 *) AvoidL__INTSTAT)
    #define AvoidL_SNAP               (* (reg8 *) AvoidL__SNAP)
    
	#define AvoidL_0_INTTYPE_REG 		(* (reg8 *) AvoidL__0__INTTYPE)
#endif /* (AvoidL__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_AvoidL_H */


/* [] END OF FILE */
