/*******************************************************************************
* File Name: Compass.c
* Version 3.50
*
* Description:
*  This file provides the source code of APIs for the I2C component.
*  The actual protocol and operation code resides in the interrupt service
*  routine file.
*
*******************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "Compass_PVT.h"


/**********************************
*      System variables
**********************************/

uint8 Compass_initVar = 0u; /* Defines if component was initialized */

volatile uint8 Compass_state;  /* Current state of I2C FSM */


/*******************************************************************************
* Function Name: Compass_Init
********************************************************************************
*
* Summary:
*  Initializes I2C registers with initial values provided from customizer.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global variables:
*  None.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void Compass_Init(void) 
{
#if (Compass_FF_IMPLEMENTED)
    /* Configure fixed function block */
    Compass_CFG_REG  = Compass_DEFAULT_CFG;
    Compass_XCFG_REG = Compass_DEFAULT_XCFG;
    Compass_ADDR_REG = Compass_DEFAULT_ADDR;
    Compass_CLKDIV1_REG = LO8(Compass_DEFAULT_DIVIDE_FACTOR);
    Compass_CLKDIV2_REG = HI8(Compass_DEFAULT_DIVIDE_FACTOR);

#else
    uint8 intState;

    /* Configure control and interrupt sources */
    Compass_CFG_REG      = Compass_DEFAULT_CFG;
    Compass_INT_MASK_REG = Compass_DEFAULT_INT_MASK;

    /* Enable interrupt generation in status */
    intState = CyEnterCriticalSection();
    Compass_INT_ENABLE_REG |= Compass_INTR_ENABLE;
    CyExitCriticalSection(intState);

    /* Configure bit counter */
    #if (Compass_MODE_SLAVE_ENABLED)
        Compass_PERIOD_REG = Compass_DEFAULT_PERIOD;
    #endif  /* (Compass_MODE_SLAVE_ENABLED) */

    /* Configure clock generator */
    #if (Compass_MODE_MASTER_ENABLED)
        Compass_MCLK_PRD_REG = Compass_DEFAULT_MCLK_PRD;
        Compass_MCLK_CMP_REG = Compass_DEFAULT_MCLK_CMP;
    #endif /* (Compass_MODE_MASTER_ENABLED) */
#endif /* (Compass_FF_IMPLEMENTED) */

#if (Compass_TIMEOUT_ENABLED)
    Compass_TimeoutInit();
#endif /* (Compass_TIMEOUT_ENABLED) */

    /* Configure internal interrupt */
    CyIntDisable    (Compass_ISR_NUMBER);
    CyIntSetPriority(Compass_ISR_NUMBER, Compass_ISR_PRIORITY);
    #if (Compass_INTERN_I2C_INTR_HANDLER)
        (void) CyIntSetVector(Compass_ISR_NUMBER, &Compass_ISR);
    #endif /* (Compass_INTERN_I2C_INTR_HANDLER) */

    /* Set FSM to default state */
    Compass_state = Compass_SM_IDLE;

#if (Compass_MODE_SLAVE_ENABLED)
    /* Clear status and buffers index */
    Compass_slStatus = 0u;
    Compass_slRdBufIndex = 0u;
    Compass_slWrBufIndex = 0u;

    /* Configure matched address */
    Compass_SlaveSetAddress(Compass_DEFAULT_ADDR);
#endif /* (Compass_MODE_SLAVE_ENABLED) */

#if (Compass_MODE_MASTER_ENABLED)
    /* Clear status and buffers index */
    Compass_mstrStatus = 0u;
    Compass_mstrRdBufIndex = 0u;
    Compass_mstrWrBufIndex = 0u;
#endif /* (Compass_MODE_MASTER_ENABLED) */
}


/*******************************************************************************
* Function Name: Compass_Enable
********************************************************************************
*
* Summary:
*  Enables I2C operations.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Global variables:
*  None.
*
*******************************************************************************/
void Compass_Enable(void) 
{
#if (Compass_FF_IMPLEMENTED)
    uint8 intState;

    /* Enable power to block */
    intState = CyEnterCriticalSection();
    Compass_ACT_PWRMGR_REG  |= Compass_ACT_PWR_EN;
    Compass_STBY_PWRMGR_REG |= Compass_STBY_PWR_EN;
    CyExitCriticalSection(intState);
#else
    #if (Compass_MODE_SLAVE_ENABLED)
        /* Enable bit counter */
        uint8 intState = CyEnterCriticalSection();
        Compass_COUNTER_AUX_CTL_REG |= Compass_CNT7_ENABLE;
        CyExitCriticalSection(intState);
    #endif /* (Compass_MODE_SLAVE_ENABLED) */

    /* Enable slave or master bits */
    Compass_CFG_REG |= Compass_ENABLE_MS;
#endif /* (Compass_FF_IMPLEMENTED) */

#if (Compass_TIMEOUT_ENABLED)
    Compass_TimeoutEnable();
#endif /* (Compass_TIMEOUT_ENABLED) */
}


/*******************************************************************************
* Function Name: Compass_Start
********************************************************************************
*
* Summary:
*  Starts the I2C hardware. Enables Active mode power template bits or clock
*  gating as appropriate. It is required to be executed before I2C bus
*  operation.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
* Side Effects:
*  This component automatically enables its interrupt.  If I2C is enabled !
*  without the interrupt enabled, it can lock up the I2C bus.
*
* Global variables:
*  Compass_initVar - This variable is used to check the initial
*                             configuration, modified on the first
*                             function call.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void Compass_Start(void) 
{
    if (0u == Compass_initVar)
    {
        Compass_Init();
        Compass_initVar = 1u; /* Component initialized */
    }

    Compass_Enable();
    Compass_EnableInt();
}


/*******************************************************************************
* Function Name: Compass_Stop
********************************************************************************
*
* Summary:
*  Disables I2C hardware and disables I2C interrupt. Disables Active mode power
*  template bits or clock gating as appropriate.
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
void Compass_Stop(void) 
{
    Compass_DisableInt();

#if (Compass_TIMEOUT_ENABLED)
    Compass_TimeoutStop();
#endif  /* End (Compass_TIMEOUT_ENABLED) */

#if (Compass_FF_IMPLEMENTED)
    {
        uint8 intState;
        uint16 blockResetCycles;

        /* Store registers effected by block disable */
        Compass_backup.addr    = Compass_ADDR_REG;
        Compass_backup.clkDiv1 = Compass_CLKDIV1_REG;
        Compass_backup.clkDiv2 = Compass_CLKDIV2_REG;

        /* Calculate number of cycles to reset block */
        blockResetCycles = ((uint16) ((uint16) Compass_CLKDIV2_REG << 8u) | Compass_CLKDIV1_REG) + 1u;

        /* Disable block */
        Compass_CFG_REG &= (uint8) ~Compass_CFG_EN_SLAVE;
        /* Wait for block reset before disable power */
        CyDelayCycles((uint32) blockResetCycles);

        /* Disable power to block */
        intState = CyEnterCriticalSection();
        Compass_ACT_PWRMGR_REG  &= (uint8) ~Compass_ACT_PWR_EN;
        Compass_STBY_PWRMGR_REG &= (uint8) ~Compass_STBY_PWR_EN;
        CyExitCriticalSection(intState);

        /* Enable block */
        Compass_CFG_REG |= (uint8) Compass_ENABLE_MS;

        /* Restore registers effected by block disable. Ticket ID#198004 */
        Compass_ADDR_REG    = Compass_backup.addr;
        Compass_ADDR_REG    = Compass_backup.addr;
        Compass_CLKDIV1_REG = Compass_backup.clkDiv1;
        Compass_CLKDIV2_REG = Compass_backup.clkDiv2;
    }
#else

    /* Disable slave or master bits */
    Compass_CFG_REG &= (uint8) ~Compass_ENABLE_MS;

#if (Compass_MODE_SLAVE_ENABLED)
    {
        /* Disable bit counter */
        uint8 intState = CyEnterCriticalSection();
        Compass_COUNTER_AUX_CTL_REG &= (uint8) ~Compass_CNT7_ENABLE;
        CyExitCriticalSection(intState);
    }
#endif /* (Compass_MODE_SLAVE_ENABLED) */

    /* Clear interrupt source register */
    (void) Compass_CSR_REG;
#endif /* (Compass_FF_IMPLEMENTED) */

    /* Disable interrupt on stop (enabled by write transaction) */
    Compass_DISABLE_INT_ON_STOP;
    Compass_ClearPendingInt();

    /* Reset FSM to default state */
    Compass_state = Compass_SM_IDLE;

    /* Clear busy statuses */
#if (Compass_MODE_SLAVE_ENABLED)
    Compass_slStatus &= (uint8) ~(Compass_SSTAT_RD_BUSY | Compass_SSTAT_WR_BUSY);
#endif /* (Compass_MODE_SLAVE_ENABLED) */
}


/* [] END OF FILE */
