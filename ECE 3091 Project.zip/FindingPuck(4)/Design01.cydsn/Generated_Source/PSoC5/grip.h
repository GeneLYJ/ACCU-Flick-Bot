/*******************************************************************************
* File Name: grip.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_grip_H) /* Pins grip_H */
#define CY_PINS_grip_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "grip_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 grip__PORT == 15 && ((grip__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    grip_Write(uint8 value);
void    grip_SetDriveMode(uint8 mode);
uint8   grip_ReadDataReg(void);
uint8   grip_Read(void);
void    grip_SetInterruptMode(uint16 position, uint16 mode);
uint8   grip_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the grip_SetDriveMode() function.
     *  @{
     */
        #define grip_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define grip_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define grip_DM_RES_UP          PIN_DM_RES_UP
        #define grip_DM_RES_DWN         PIN_DM_RES_DWN
        #define grip_DM_OD_LO           PIN_DM_OD_LO
        #define grip_DM_OD_HI           PIN_DM_OD_HI
        #define grip_DM_STRONG          PIN_DM_STRONG
        #define grip_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define grip_MASK               grip__MASK
#define grip_SHIFT              grip__SHIFT
#define grip_WIDTH              1u

/* Interrupt constants */
#if defined(grip__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in grip_SetInterruptMode() function.
     *  @{
     */
        #define grip_INTR_NONE      (uint16)(0x0000u)
        #define grip_INTR_RISING    (uint16)(0x0001u)
        #define grip_INTR_FALLING   (uint16)(0x0002u)
        #define grip_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define grip_INTR_MASK      (0x01u) 
#endif /* (grip__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define grip_PS                     (* (reg8 *) grip__PS)
/* Data Register */
#define grip_DR                     (* (reg8 *) grip__DR)
/* Port Number */
#define grip_PRT_NUM                (* (reg8 *) grip__PRT) 
/* Connect to Analog Globals */                                                  
#define grip_AG                     (* (reg8 *) grip__AG)                       
/* Analog MUX bux enable */
#define grip_AMUX                   (* (reg8 *) grip__AMUX) 
/* Bidirectional Enable */                                                        
#define grip_BIE                    (* (reg8 *) grip__BIE)
/* Bit-mask for Aliased Register Access */
#define grip_BIT_MASK               (* (reg8 *) grip__BIT_MASK)
/* Bypass Enable */
#define grip_BYP                    (* (reg8 *) grip__BYP)
/* Port wide control signals */                                                   
#define grip_CTL                    (* (reg8 *) grip__CTL)
/* Drive Modes */
#define grip_DM0                    (* (reg8 *) grip__DM0) 
#define grip_DM1                    (* (reg8 *) grip__DM1)
#define grip_DM2                    (* (reg8 *) grip__DM2) 
/* Input Buffer Disable Override */
#define grip_INP_DIS                (* (reg8 *) grip__INP_DIS)
/* LCD Common or Segment Drive */
#define grip_LCD_COM_SEG            (* (reg8 *) grip__LCD_COM_SEG)
/* Enable Segment LCD */
#define grip_LCD_EN                 (* (reg8 *) grip__LCD_EN)
/* Slew Rate Control */
#define grip_SLW                    (* (reg8 *) grip__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define grip_PRTDSI__CAPS_SEL       (* (reg8 *) grip__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define grip_PRTDSI__DBL_SYNC_IN    (* (reg8 *) grip__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define grip_PRTDSI__OE_SEL0        (* (reg8 *) grip__PRTDSI__OE_SEL0) 
#define grip_PRTDSI__OE_SEL1        (* (reg8 *) grip__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define grip_PRTDSI__OUT_SEL0       (* (reg8 *) grip__PRTDSI__OUT_SEL0) 
#define grip_PRTDSI__OUT_SEL1       (* (reg8 *) grip__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define grip_PRTDSI__SYNC_OUT       (* (reg8 *) grip__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(grip__SIO_CFG)
    #define grip_SIO_HYST_EN        (* (reg8 *) grip__SIO_HYST_EN)
    #define grip_SIO_REG_HIFREQ     (* (reg8 *) grip__SIO_REG_HIFREQ)
    #define grip_SIO_CFG            (* (reg8 *) grip__SIO_CFG)
    #define grip_SIO_DIFF           (* (reg8 *) grip__SIO_DIFF)
#endif /* (grip__SIO_CFG) */

/* Interrupt Registers */
#if defined(grip__INTSTAT)
    #define grip_INTSTAT            (* (reg8 *) grip__INTSTAT)
    #define grip_SNAP               (* (reg8 *) grip__SNAP)
    
	#define grip_0_INTTYPE_REG 		(* (reg8 *) grip__0__INTTYPE)
#endif /* (grip__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_grip_H */


/* [] END OF FILE */
