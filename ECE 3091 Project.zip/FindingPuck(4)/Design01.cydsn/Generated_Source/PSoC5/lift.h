/*******************************************************************************
* File Name: lift.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_lift_H) /* Pins lift_H */
#define CY_PINS_lift_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "lift_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 lift__PORT == 15 && ((lift__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    lift_Write(uint8 value);
void    lift_SetDriveMode(uint8 mode);
uint8   lift_ReadDataReg(void);
uint8   lift_Read(void);
void    lift_SetInterruptMode(uint16 position, uint16 mode);
uint8   lift_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the lift_SetDriveMode() function.
     *  @{
     */
        #define lift_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define lift_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define lift_DM_RES_UP          PIN_DM_RES_UP
        #define lift_DM_RES_DWN         PIN_DM_RES_DWN
        #define lift_DM_OD_LO           PIN_DM_OD_LO
        #define lift_DM_OD_HI           PIN_DM_OD_HI
        #define lift_DM_STRONG          PIN_DM_STRONG
        #define lift_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define lift_MASK               lift__MASK
#define lift_SHIFT              lift__SHIFT
#define lift_WIDTH              1u

/* Interrupt constants */
#if defined(lift__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in lift_SetInterruptMode() function.
     *  @{
     */
        #define lift_INTR_NONE      (uint16)(0x0000u)
        #define lift_INTR_RISING    (uint16)(0x0001u)
        #define lift_INTR_FALLING   (uint16)(0x0002u)
        #define lift_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define lift_INTR_MASK      (0x01u) 
#endif /* (lift__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define lift_PS                     (* (reg8 *) lift__PS)
/* Data Register */
#define lift_DR                     (* (reg8 *) lift__DR)
/* Port Number */
#define lift_PRT_NUM                (* (reg8 *) lift__PRT) 
/* Connect to Analog Globals */                                                  
#define lift_AG                     (* (reg8 *) lift__AG)                       
/* Analog MUX bux enable */
#define lift_AMUX                   (* (reg8 *) lift__AMUX) 
/* Bidirectional Enable */                                                        
#define lift_BIE                    (* (reg8 *) lift__BIE)
/* Bit-mask for Aliased Register Access */
#define lift_BIT_MASK               (* (reg8 *) lift__BIT_MASK)
/* Bypass Enable */
#define lift_BYP                    (* (reg8 *) lift__BYP)
/* Port wide control signals */                                                   
#define lift_CTL                    (* (reg8 *) lift__CTL)
/* Drive Modes */
#define lift_DM0                    (* (reg8 *) lift__DM0) 
#define lift_DM1                    (* (reg8 *) lift__DM1)
#define lift_DM2                    (* (reg8 *) lift__DM2) 
/* Input Buffer Disable Override */
#define lift_INP_DIS                (* (reg8 *) lift__INP_DIS)
/* LCD Common or Segment Drive */
#define lift_LCD_COM_SEG            (* (reg8 *) lift__LCD_COM_SEG)
/* Enable Segment LCD */
#define lift_LCD_EN                 (* (reg8 *) lift__LCD_EN)
/* Slew Rate Control */
#define lift_SLW                    (* (reg8 *) lift__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define lift_PRTDSI__CAPS_SEL       (* (reg8 *) lift__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define lift_PRTDSI__DBL_SYNC_IN    (* (reg8 *) lift__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define lift_PRTDSI__OE_SEL0        (* (reg8 *) lift__PRTDSI__OE_SEL0) 
#define lift_PRTDSI__OE_SEL1        (* (reg8 *) lift__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define lift_PRTDSI__OUT_SEL0       (* (reg8 *) lift__PRTDSI__OUT_SEL0) 
#define lift_PRTDSI__OUT_SEL1       (* (reg8 *) lift__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define lift_PRTDSI__SYNC_OUT       (* (reg8 *) lift__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(lift__SIO_CFG)
    #define lift_SIO_HYST_EN        (* (reg8 *) lift__SIO_HYST_EN)
    #define lift_SIO_REG_HIFREQ     (* (reg8 *) lift__SIO_REG_HIFREQ)
    #define lift_SIO_CFG            (* (reg8 *) lift__SIO_CFG)
    #define lift_SIO_DIFF           (* (reg8 *) lift__SIO_DIFF)
#endif /* (lift__SIO_CFG) */

/* Interrupt Registers */
#if defined(lift__INTSTAT)
    #define lift_INTSTAT            (* (reg8 *) lift__INTSTAT)
    #define lift_SNAP               (* (reg8 *) lift__SNAP)
    
	#define lift_0_INTTYPE_REG 		(* (reg8 *) lift__0__INTTYPE)
#endif /* (lift__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_lift_H */


/* [] END OF FILE */
